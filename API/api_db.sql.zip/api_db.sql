-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Servidor: db:3306
-- Tiempo de generación: 26-04-2025 a las 15:57:16
-- Versión del servidor: 8.0.42
-- Versión de PHP: 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `api_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `doctrine_migration_versions`
--

CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8mb3_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Volcado de datos para la tabla `doctrine_migration_versions`
--

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20250422100852', '2025-04-22 10:09:16', 254),
('DoctrineMigrations\\Version20250422101615', '2025-04-22 10:16:24', 106);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Pokemon`
--

CREATE TABLE `Pokemon` (
  `ID_Pokemon` int NOT NULL,
  `ID_Api` int NOT NULL,
  `Nombre` varchar(255) NOT NULL,
  `Imagen` varchar(255) DEFAULT NULL,
  `Imagen 2D` varchar(255) DEFAULT NULL,
  `Gif` varchar(255) DEFAULT NULL,
  `Descripcion` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `Pokemon`
--

INSERT INTO `Pokemon` (`ID_Pokemon`, `ID_Api`, `Nombre`, `Imagen`, `Imagen 2D`, `Gif`, `Descripcion`) VALUES
(1, 1, 'bulbasaur', '/uploads/pokemon/bulbasaur.png', '/uploads/pokemon/bulbasaur_icon.png', '/uploads/pokemon/bulbasaur.gif', 'Una rara semilla le fue plantada en el lomo al nacer.\nLa planta brota y crece con este Pokémon.'),
(2, 2, 'ivysaur', '/uploads/pokemon/ivysaur.png', '/uploads/pokemon/ivysaur_icon.png', '/uploads/pokemon/ivysaur.gif', 'Este Pokémon tiene un bulbo en el lomo. Dicen que,\nal absorber nutrientes, el bulbo se transforma en una\nflor grande.'),
(3, 3, 'venusaur', '/uploads/pokemon/venusaur.png', '/uploads/pokemon/venusaur_icon.png', '/uploads/pokemon/venusaur.gif', 'Llena su cuerpo de energía con los rayos solares que\ncaptan los anchos pétalos de su flor.'),
(4, 4, 'charmander', '/uploads/pokemon/charmander.png', '/uploads/pokemon/charmander_icon.png', '/uploads/pokemon/charmander.gif', 'La llama de su cola indica la fuerza vital de\nCharmander. Será brillante si está sano.'),
(5, 5, 'charmeleon', '/uploads/pokemon/charmeleon.png', '/uploads/pokemon/charmeleon_icon.png', '/uploads/pokemon/charmeleon.gif', 'Suele usar la cola para derribar a su rival. Cuando lo\ntira, se vale de sus afiladas garras para acabar con él.'),
(6, 6, 'charizard', '/uploads/pokemon/charizard.png', '/uploads/pokemon/charizard_icon.png', '/uploads/pokemon/charizard.gif', 'Cuando lanza una descarga de fuego supercaliente, la\nroja llama de su cola brilla más intensamente.'),
(7, 7, 'squirtle', '/uploads/pokemon/squirtle.png', '/uploads/pokemon/squirtle_icon.png', '/uploads/pokemon/squirtle.gif', 'Se protege con su caparazón y luego contraataca\nlanzando agua a presión cuando tiene oportunidad.'),
(8, 8, 'wartortle', '/uploads/pokemon/wartortle.png', '/uploads/pokemon/wartortle_icon.png', '/uploads/pokemon/wartortle.gif', 'Si es golpeado, esconderá su cabeza. Aun así, su cola\npuede seguir golpeando.'),
(9, 9, 'blastoise', '/uploads/pokemon/blastoise.png', '/uploads/pokemon/blastoise_icon.png', '/uploads/pokemon/blastoise.gif', 'Para acabar con su enemigo, lo aplasta con el peso de\nsu cuerpo. En momentos de apuro, se esconde en el\ncaparazón.'),
(10, 10, 'caterpie', '/uploads/pokemon/caterpie.png', '/uploads/pokemon/caterpie_icon.png', '/uploads/pokemon/caterpie.gif', 'Para protegerse despide un hedor horrible de sus\nantenas, con el que repele a sus enemigos.'),
(11, 11, 'metapod', '/uploads/pokemon/metapod.png', '/uploads/pokemon/metapod_icon.png', '/uploads/pokemon/metapod.gif', 'Su frágil cuerpo está recubierto de una coraza dura\ncomo el acero. Permanece quieto en su desarrollo.'),
(12, 12, 'butterfree', '/uploads/pokemon/butterfree.png', '/uploads/pokemon/butterfree_icon.png', '/uploads/pokemon/butterfree.gif', 'Adora el néctar de las flores. Puede localizar hasta las\nmás pequeñas cantidades de polen.'),
(13, 13, 'weedle', '/uploads/pokemon/weedle.png', '/uploads/pokemon/weedle_icon.png', '/uploads/pokemon/weedle.gif', 'Suele habitar bosques y praderas. Tiene un afilado y\nvenenoso aguijón de unos 5 cm encima de la cabeza.'),
(14, 14, 'kakuna', '/uploads/pokemon/kakuna.png', '/uploads/pokemon/kakuna_icon.png', '/uploads/pokemon/kakuna.gif', 'Casi incapaz de moverse, este Pokémon solo puede\nendurecer su caparazón para protegerse.'),
(15, 15, 'beedrill', '/uploads/pokemon/beedrill.png', '/uploads/pokemon/beedrill_icon.png', '/uploads/pokemon/beedrill.gif', 'Tiene 3 aguijones venenosos en sus patas y cola.\nSuelen pinchar a sus enemigos repetidas veces.'),
(16, 16, 'pidgey', '/uploads/pokemon/pidgey.png', '/uploads/pokemon/pidgey_icon.png', '/uploads/pokemon/pidgey.gif', 'Muy común en bosques y selvas. Aletea al nivel del\nsuelo para levantar la gravilla.'),
(17, 17, 'pidgeotto', '/uploads/pokemon/pidgeotto.png', '/uploads/pokemon/pidgeotto_icon.png', '/uploads/pokemon/pidgeotto.gif', 'Tiene unas garras desarrolladas. Puede atrapar un\nExeggcute y transportarlo desde una distancia de\ncasi 100 km.'),
(18, 18, 'pidgeot', '/uploads/pokemon/pidgeot.png', '/uploads/pokemon/pidgeot_icon.png', '/uploads/pokemon/pidgeot.gif', 'Cuando caza, vuela muy deprisa a ras del agua y\nsorprende a inocentes presas como Magikarp.'),
(19, 19, 'rattata', '/uploads/pokemon/rattata.png', '/uploads/pokemon/rattata_icon.png', '/uploads/pokemon/rattata.gif', 'Vive allí donde haya comida disponible. Busca todo\nel día, sin descanso, algo comestible.'),
(20, 20, 'raticate', '/uploads/pokemon/raticate.png', '/uploads/pokemon/raticate_icon.png', '/uploads/pokemon/raticate.gif', 'Lima sus colmillos royendo objetos duros. Con ellos\npuede destruir incluso paredes de hormigón.'),
(21, 21, 'spearow', '/uploads/pokemon/spearow.png', '/uploads/pokemon/spearow_icon.png', '/uploads/pokemon/spearow.gif', 'Muy protector de su territorio, mueve sus cortas alas\nsin descanso para lanzarse a toda velocidad.'),
(22, 22, 'fearow', '/uploads/pokemon/fearow.png', '/uploads/pokemon/fearow_icon.png', '/uploads/pokemon/fearow.gif', 'Con sus enormes y magníficas alas, puede seguir\nvolando sin tener que aterrizar para descansar.'),
(23, 23, 'ekans', '/uploads/pokemon/ekans.png', '/uploads/pokemon/ekans_icon.png', '/uploads/pokemon/ekans.gif', 'Cuanto más viejo, más crece este Pokémon. Por la\nnoche, descansa en las ramas de los árboles.'),
(24, 24, 'arbok', '/uploads/pokemon/arbok.png', '/uploads/pokemon/arbok_icon.png', '/uploads/pokemon/arbok.gif', 'El dibujo que tiene en la panza aterroriza. Los rivales\nmás débiles salen huyendo al verlo.'),
(25, 25, 'pikachu', '/uploads/pokemon/pikachu.png', '/uploads/pokemon/pikachu_icon.png', '/uploads/pokemon/pikachu.gif', 'Levanta su cola para vigilar los alrededores. A veces,\npuede ser alcanzado por un rayo en esa pose.'),
(26, 26, 'raichu', '/uploads/pokemon/raichu.png', '/uploads/pokemon/raichu_icon.png', '/uploads/pokemon/raichu.gif', 'Cuando se carga de electricidad, sus músculos se\ntensan y se vuelve más agresivo de lo normal.'),
(27, 27, 'sandshrew', '/uploads/pokemon/sandshrew.png', '/uploads/pokemon/sandshrew_icon.png', '/uploads/pokemon/sandshrew.gif', 'Este Pokémon permanece bajo tierra. Si se siente\namenazado, se enrosca para defenderse.'),
(28, 28, 'sandslash', '/uploads/pokemon/sandslash.png', '/uploads/pokemon/sandslash_icon.png', '/uploads/pokemon/sandslash.gif', 'Si cava a gran velocidad, puede que se le caigan las\ngarras y púas. Vuelven a crecerle en un día.'),
(29, 29, 'nidoran-f', '/uploads/pokemon/nidoran-f.png', '/uploads/pokemon/nidoran-f_icon.png', '/uploads/pokemon/nidoran-f.gif', 'Aunque pequeñas, sus venenosas púas son muy\npeligrosas. Tienen un cuerno más pequeño que\nlos machos.'),
(30, 30, 'nidorina', '/uploads/pokemon/nidorina.png', '/uploads/pokemon/nidorina_icon.png', '/uploads/pokemon/nidorina.gif', 'Tiene un carácter afable. Emite ondas ultrasónicas\npara confundir al enemigo.'),
(31, 31, 'nidoqueen', '/uploads/pokemon/nidoqueen.png', '/uploads/pokemon/nidoqueen_icon.png', '/uploads/pokemon/nidoqueen.gif', 'Usa su cuerpo duro y escamoso para sellar la entrada\na su madriguera y protegerse de los depredadores.'),
(32, 32, 'nidoran-m', '/uploads/pokemon/nidoran-m.png', '/uploads/pokemon/nidoran-m_icon.png', '/uploads/pokemon/nidoran-m.gif', 'Saca las orejas por encima de la hierba para explorar\nel territorio. Le protege su cuerno venenoso.'),
(33, 33, 'nidorino', '/uploads/pokemon/nidorino.png', '/uploads/pokemon/nidorino_icon.png', '/uploads/pokemon/nidorino.gif', 'Levanta sus grandes orejas para vigilar. Si detecta\nalgo, atacará de inmediato.'),
(34, 34, 'nidoking', '/uploads/pokemon/nidoking.png', '/uploads/pokemon/nidoking_icon.png', '/uploads/pokemon/nidoking.gif', 'Es fácil reconocerlo por tener una dura piel y un gran\ncuerno lleno de peligrosísimo veneno.'),
(35, 35, 'clefairy', '/uploads/pokemon/clefairy.png', '/uploads/pokemon/clefairy_icon.png', '/uploads/pokemon/clefairy.gif', 'Se dice que la felicidad llegará a quien vea a un grupo\nde Clefairy bailando a la luz de la luna llena.'),
(36, 36, 'clefable', '/uploads/pokemon/clefable.png', '/uploads/pokemon/clefable_icon.png', '/uploads/pokemon/clefable.gif', 'Su oído es tan agudo que puede oír una aguja caer a\n1 km. Vive en montañas solitarias.'),
(37, 37, 'vulpix', '/uploads/pokemon/vulpix.png', '/uploads/pokemon/vulpix_icon.png', '/uploads/pokemon/vulpix.gif', 'Cuando nace solo tiene una cola, pero a medida que\ncrece, esta se va dividiendo desde la punta.'),
(38, 38, 'ninetales', '/uploads/pokemon/ninetales.png', '/uploads/pokemon/ninetales_icon.png', '/uploads/pokemon/ninetales.gif', 'Tiene nueve colas y un pelaje de color dorado.\nDicen que este Pokémon llega a vivir 1000 años.'),
(39, 39, 'jigglypuff', '/uploads/pokemon/jigglypuff.png', '/uploads/pokemon/jigglypuff_icon.png', '/uploads/pokemon/jigglypuff.gif', 'Cautiva con la mirada a su enemigo y hace que se\nquede profundamente dormido mientras entona una\ndulce melodía.'),
(40, 40, 'wigglytuff', '/uploads/pokemon/wigglytuff.png', '/uploads/pokemon/wigglytuff_icon.png', '/uploads/pokemon/wigglytuff.gif', 'Su piel es tan suave que si dos de ellos se acurrucan\njuntos, no querrán separarse nunca.'),
(41, 41, 'zubat', '/uploads/pokemon/zubat.png', '/uploads/pokemon/zubat_icon.png', '/uploads/pokemon/zubat.gif', 'Aunque carezca de ojos, puede detectar obstáculos\ncon las ondas ultrasónicas que emite su boca.'),
(42, 42, 'golbat', '/uploads/pokemon/golbat.png', '/uploads/pokemon/golbat_icon.png', '/uploads/pokemon/golbat.gif', 'Cuando ataque, seguirá chupando energía de su\nvíctima, aunque pese tanto que ya no pueda volar.'),
(43, 43, 'oddish', '/uploads/pokemon/oddish.png', '/uploads/pokemon/oddish_icon.png', '/uploads/pokemon/oddish.gif', 'Durante el día, se agazapa en el frío subsuelo huyendo\ndel sol. La luz de la luna le hace crecer mucho.'),
(44, 44, 'gloom', '/uploads/pokemon/gloom.png', '/uploads/pokemon/gloom_icon.png', '/uploads/pokemon/gloom.gif', '¡Huele bastante mal! De todas formas, una de cada\nmil personas aprecian su fétido olor.'),
(45, 45, 'vileplume', '/uploads/pokemon/vileplume.png', '/uploads/pokemon/vileplume_icon.png', '/uploads/pokemon/vileplume.gif', 'Cuanto mayores son sus pétalos, más tóxico es su\npolen. Le pesa la cabeza y le cuesta mantenerla\nerguida.'),
(46, 46, 'paras', '/uploads/pokemon/paras.png', '/uploads/pokemon/paras_icon.png', '/uploads/pokemon/paras.gif', 'Lleva en el lomo dos setas parásitas llamadas\ntochukaso, que crecen con él.'),
(47, 47, 'parasect', '/uploads/pokemon/parasect.png', '/uploads/pokemon/parasect_icon.png', '/uploads/pokemon/parasect.gif', 'Parasect está dominado por una seta parásita mayor\nque él. Dispersa esporas venenosas.'),
(48, 48, 'venonat', '/uploads/pokemon/venonat.png', '/uploads/pokemon/venonat_icon.png', '/uploads/pokemon/venonat.gif', 'Sus grandes ojos son en realidad grupos de ojos\ndiminutos. Por la noche se siente atraído por la luz.'),
(49, 49, 'venomoth', '/uploads/pokemon/venomoth.png', '/uploads/pokemon/venomoth_icon.png', '/uploads/pokemon/venomoth.gif', 'Lanza unas escamas que paralizan a cualquiera.\nQuien las toque, no podrá ni ponerse de pie.'),
(50, 50, 'diglett', '/uploads/pokemon/diglett.png', '/uploads/pokemon/diglett_icon.png', '/uploads/pokemon/diglett.gif', 'Vive un metro por debajo del suelo, donde se alimenta\nde raíces. También aparece en la superficie.'),
(51, 51, 'dugtrio', '/uploads/pokemon/dugtrio.png', '/uploads/pokemon/dugtrio_icon.png', '/uploads/pokemon/dugtrio.gif', 'En combate, cava la tierra, se esconde y sale de\nrepente para golpear a su rival. Nunca se sabe por\ndónde puede aparecer.'),
(52, 52, 'meowth', '/uploads/pokemon/meowth.png', '/uploads/pokemon/meowth_icon.png', '/uploads/pokemon/meowth.gif', 'Es de naturaleza nocturna. Le atraen los objetos\nbrillantes.'),
(53, 53, 'persian', '/uploads/pokemon/persian.png', '/uploads/pokemon/persian_icon.png', '/uploads/pokemon/persian.gif', 'Aunque es muy admirado por el pelo, es difícil de\nentrenar como mascota, porque es un poco travieso.'),
(54, 54, 'psyduck', '/uploads/pokemon/psyduck.png', '/uploads/pokemon/psyduck_icon.png', '/uploads/pokemon/psyduck.gif', 'Padece continuamente dolores de cabeza. Cuando\nson muy fuertes, empieza a usar misteriosos poderes.'),
(55, 55, 'golduck', '/uploads/pokemon/golduck.png', '/uploads/pokemon/golduck_icon.png', '/uploads/pokemon/golduck.gif', 'Aparece en ríos al anochecer. Puede usar poderes\ntelequinéticos si su frente brilla misteriosamente.'),
(56, 56, 'mankey', '/uploads/pokemon/mankey.png', '/uploads/pokemon/mankey_icon.png', '/uploads/pokemon/mankey.gif', 'Es peligroso acercarse si se enfada sin razón aparente,\nya que no distingue entre amigos y enemigos.'),
(57, 57, 'primeape', '/uploads/pokemon/primeape.png', '/uploads/pokemon/primeape_icon.png', '/uploads/pokemon/primeape.gif', 'Solo se calma cuando nadie está cerca. Llegar a ver\nese momento es realmente difícil.'),
(58, 58, 'growlithe', '/uploads/pokemon/growlithe.png', '/uploads/pokemon/growlithe_icon.png', '/uploads/pokemon/growlithe.gif', 'Es muy agradable y leal. Para ahuyentar al enemigo,\nse pone a ladrar y a dar bocados.'),
(59, 59, 'arcanine', '/uploads/pokemon/arcanine.png', '/uploads/pokemon/arcanine_icon.png', '/uploads/pokemon/arcanine.gif', 'Un Pokémon muy admirado desde la antigüedad por\nsu belleza. Corre ágilmente como si tuviera alas.'),
(60, 60, 'poliwag', '/uploads/pokemon/poliwag.png', '/uploads/pokemon/poliwag_icon.png', '/uploads/pokemon/poliwag.gif', 'Tiene una piel extraordinaria, fina y húmeda, que deja\nentrever las vísceras que tiene dispuestas en espiral.'),
(61, 61, 'poliwhirl', '/uploads/pokemon/poliwhirl.png', '/uploads/pokemon/poliwhirl_icon.png', '/uploads/pokemon/poliwhirl.gif', 'Capaz de vivir dentro o fuera del agua. Fuera del agua\nsuda para mantener baboso su cuerpo.'),
(62, 62, 'poliwrath', '/uploads/pokemon/poliwrath.png', '/uploads/pokemon/poliwrath_icon.png', '/uploads/pokemon/poliwrath.gif', 'Tiene músculos muy desarrollados. Es capaz de nadar\nen el océano sin descanso.'),
(63, 63, 'abra', '/uploads/pokemon/abra.png', '/uploads/pokemon/abra_icon.png', '/uploads/pokemon/abra.gif', 'Duerme 18 horas al día y mientras lo hace es capaz de\nusar una serie de poderes extrasensoriales.'),
(64, 64, 'kadabra', '/uploads/pokemon/kadabra.png', '/uploads/pokemon/kadabra_icon.png', '/uploads/pokemon/kadabra.gif', 'Cuando utiliza su poder psíquico, emite poderosas\nondas alfa que pueden destruir dispositivos.'),
(65, 65, 'alakazam', '/uploads/pokemon/alakazam.png', '/uploads/pokemon/alakazam_icon.png', '/uploads/pokemon/alakazam.gif', 'Sus neuronas se multiplican continuamente durante su\nvida. Por eso, siempre lo recuerda todo.'),
(66, 66, 'machop', '/uploads/pokemon/machop.png', '/uploads/pokemon/machop_icon.png', '/uploads/pokemon/machop.gif', 'Levanta un Graveler para mantener sus músculos en\nforma. Domina todas las artes marciales.'),
(67, 67, 'machoke', '/uploads/pokemon/machoke.png', '/uploads/pokemon/machoke_icon.png', '/uploads/pokemon/machoke.gif', 'Su musculoso cuerpo es tan fuerte que usa un cinto\nantifuerza para controlar sus movimientos.'),
(68, 68, 'machamp', '/uploads/pokemon/machamp.png', '/uploads/pokemon/machamp_icon.png', '/uploads/pokemon/machamp.gif', 'Tiene cuatro brazos tan bien desarrollados que puede\ndar una serie de 1000 puñetazos en cuestión de dos\nsegundos.'),
(69, 69, 'bellsprout', '/uploads/pokemon/bellsprout.png', '/uploads/pokemon/bellsprout_icon.png', '/uploads/pokemon/bellsprout.gif', 'Aunque su cuerpo es extremadamente delgado, es\nmuy rápido a la hora de capturar sus presas.'),
(70, 70, 'weepinbell', '/uploads/pokemon/weepinbell.png', '/uploads/pokemon/weepinbell_icon.png', '/uploads/pokemon/weepinbell.gif', 'Las hojas que tiene actúan como cuchillas en\ncombate. Otra de sus armas es el corrosivo fluido\nque expulsa.'),
(71, 71, 'victreebel', '/uploads/pokemon/victreebel.png', '/uploads/pokemon/victreebel_icon.png', '/uploads/pokemon/victreebel.gif', 'Dicen que vive en grandes colonias en el interior de\nlas junglas, aunque nadie ha podido verificarlo.'),
(72, 72, 'tentacool', '/uploads/pokemon/tentacool.png', '/uploads/pokemon/tentacool_icon.png', '/uploads/pokemon/tentacool.gif', 'Su cuerpo se compone casi en exclusiva de agua.\nLanza extraños rayos con sus ojos cristalinos.'),
(73, 73, 'tentacruel', '/uploads/pokemon/tentacruel.png', '/uploads/pokemon/tentacruel_icon.png', '/uploads/pokemon/tentacruel.gif', 'Cuando caza, extiende los cortos tentáculos que tiene\npara atrapar e inmovilizar a su presa.'),
(74, 74, 'geodude', '/uploads/pokemon/geodude.png', '/uploads/pokemon/geodude_icon.png', '/uploads/pokemon/geodude.gif', 'Aparecen en llanos y montañas. Como parecen rocas,\nla gente se tropieza con ellos o los pisa.'),
(75, 75, 'graveler', '/uploads/pokemon/graveler.png', '/uploads/pokemon/graveler_icon.png', '/uploads/pokemon/graveler.gif', 'De naturaleza descuidada y libre, no le importa\ndañarse cuando baja rodando montañas.'),
(76, 76, 'golem', '/uploads/pokemon/golem.png', '/uploads/pokemon/golem_icon.png', '/uploads/pokemon/golem.gif', 'Se lanza montaña abajo y deja un surco desde la cima\nhasta el pie. Es mejor mantenerse alejado.'),
(77, 77, 'ponyta', '/uploads/pokemon/ponyta.png', '/uploads/pokemon/ponyta_icon.png', '/uploads/pokemon/ponyta.gif', 'Cuando nace, apenas puede tenerse en pie. Pero va\nfortaleciendo las patas en cuanto empieza a galopar.'),
(78, 78, 'rapidash', '/uploads/pokemon/rapidash.png', '/uploads/pokemon/rapidash_icon.png', '/uploads/pokemon/rapidash.gif', 'Galopa a casi 240 km por hora. Su crin ardiente\nparece una flecha cuando corre.'),
(79, 79, 'slowpoke', '/uploads/pokemon/slowpoke.png', '/uploads/pokemon/slowpoke_icon.png', '/uploads/pokemon/slowpoke.gif', 'Descansa ocioso junto al agua. Si algo muerde su\ncola, no lo notará en todo el día.'),
(80, 80, 'slowbro', '/uploads/pokemon/slowbro.png', '/uploads/pokemon/slowbro_icon.png', '/uploads/pokemon/slowbro.gif', 'Tiene una cola tan apetecible, que el Shellder que va\nenganchado a ella no se soltará por nada del mundo.'),
(81, 81, 'magnemite', '/uploads/pokemon/magnemite.png', '/uploads/pokemon/magnemite_icon.png', '/uploads/pokemon/magnemite.gif', 'Las unidades a los lados de su cuerpo generan\nenergía antigravitatoria para mantenerlo en el aire.'),
(82, 82, 'magneton', '/uploads/pokemon/magneton.png', '/uploads/pokemon/magneton_icon.png', '/uploads/pokemon/magneton.gif', 'Lo constituye un grupo de Magnemite. Descarga\npotentes ondas magnéticas de alto voltaje.'),
(83, 83, 'farfetchd', '/uploads/pokemon/farfetchd.png', '/uploads/pokemon/farfetchd_icon.png', '/uploads/pokemon/farfetchd.gif', 'El puerro que lleva es su mejor arma. Suele usarlo\ncomo espada para cortar cosas.'),
(84, 84, 'doduo', '/uploads/pokemon/doduo.png', '/uploads/pokemon/doduo_icon.png', '/uploads/pokemon/doduo.gif', 'Este Pokémon de dos cabezas es el resultado de una\nmutación. Cuando corre, puede alcanzar casi 100 km\npor hora.'),
(85, 85, 'dodrio', '/uploads/pokemon/dodrio.png', '/uploads/pokemon/dodrio_icon.png', '/uploads/pokemon/dodrio.gif', 'Más vale no perder de vista ninguna de las tres\ncabezas. De lo contrario, el número de picotazos\nserá enorme.'),
(86, 86, 'seel', '/uploads/pokemon/seel.png', '/uploads/pokemon/seel_icon.png', '/uploads/pokemon/seel.gif', 'Este Pokémon vive en icebergs. Nada en el mar y usa\nel cuerno de su cabeza para romper el hielo.'),
(87, 87, 'dewgong', '/uploads/pokemon/dewgong.png', '/uploads/pokemon/dewgong_icon.png', '/uploads/pokemon/dewgong.gif', 'Está recubierto de un luminoso pelaje blanco. Este\nPokémon aumenta su actividad cuando bajan las\ntemperaturas.'),
(88, 88, 'grimer', '/uploads/pokemon/grimer.png', '/uploads/pokemon/grimer_icon.png', '/uploads/pokemon/grimer.gif', 'Nace de lodo alterado al filtrarse en el agua los\nrayos X reflejados por la Luna. Se alimenta de\nsustancias desagradables.'),
(89, 89, 'muk', '/uploads/pokemon/muk.png', '/uploads/pokemon/muk_icon.png', '/uploads/pokemon/muk.gif', 'Les encanta reunirse en zonas apestosas donde se\nacumula el lodo, haciendo su olor más insoportable.'),
(90, 90, 'shellder', '/uploads/pokemon/shellder.png', '/uploads/pokemon/shellder_icon.png', '/uploads/pokemon/shellder.gif', 'La concha lo protege de cualquier tipo de ataque.\nSolo es vulnerable cuando se abre.'),
(91, 91, 'cloyster', '/uploads/pokemon/cloyster.png', '/uploads/pokemon/cloyster_icon.png', '/uploads/pokemon/cloyster.gif', 'A los Cloyster que viven en las fuertes corrientes\nmarinas les crecen largas y afiladas púas en la concha.'),
(92, 92, 'gastly', '/uploads/pokemon/gastly.png', '/uploads/pokemon/gastly_icon.png', '/uploads/pokemon/gastly.gif', 'Su etéreo cuerpo está hecho de gas. Puede envolver\na un oponente de cualquier tamaño hasta ahogarlo.'),
(93, 93, 'haunter', '/uploads/pokemon/haunter.png', '/uploads/pokemon/haunter_icon.png', '/uploads/pokemon/haunter.gif', 'Cuando tienes la sensación de que te están\nobservando, seguro que es porque Haunter está\ncerca.'),
(94, 94, 'gengar', '/uploads/pokemon/gengar.png', '/uploads/pokemon/gengar_icon.png', '/uploads/pokemon/gengar.gif', 'Se esconde entre las sombras. Se dice que donde\nGengar acecha, la temperatura baja 5 °C.'),
(95, 95, 'onix', '/uploads/pokemon/onix.png', '/uploads/pokemon/onix_icon.png', '/uploads/pokemon/onix.gif', 'Cava a gran velocidad en busca de comida. Los\ntúneles que deja son usados por los Diglett.'),
(96, 96, 'drowzee', '/uploads/pokemon/drowzee.png', '/uploads/pokemon/drowzee_icon.png', '/uploads/pokemon/drowzee.gif', 'Adormece a sus enemigos y se come sus sueños.\nA veces se pone enfermo si come pesadillas.'),
(97, 97, 'hypno', '/uploads/pokemon/hypno.png', '/uploads/pokemon/hypno_icon.png', '/uploads/pokemon/hypno.gif', 'Lleva un péndulo en la mano. Una vez, hizo\ndesaparecer a un niño al que había hipnotizado.'),
(98, 98, 'krabby', '/uploads/pokemon/krabby.png', '/uploads/pokemon/krabby_icon.png', '/uploads/pokemon/krabby.gif', 'Ante el peligro, se camufla con las burbujas que\ndesprende su boca, para parecer más grande.'),
(99, 99, 'kingler', '/uploads/pokemon/kingler.png', '/uploads/pokemon/kingler_icon.png', '/uploads/pokemon/kingler.gif', 'La pinza tan grande que tiene posee una fuerza de\n10 000 caballos de potencia. Pero, por su gran\ntamaño, cuesta moverla.'),
(100, 100, 'voltorb', '/uploads/pokemon/voltorb.png', '/uploads/pokemon/voltorb_icon.png', '/uploads/pokemon/voltorb.gif', 'Fue descubierto cuando se crearon las Poké Balls.\nSe dice que tiene algo que ver con ellas.'),
(101, 101, 'electrode', '/uploads/pokemon/electrode.png', '/uploads/pokemon/electrode_icon.png', '/uploads/pokemon/electrode.gif', 'Explotan a la mínima. Por eso se les tiene mucho\nmiedo. Estos Pokémon reciben el mote de Bomba Ball.'),
(102, 102, 'exeggcute', '/uploads/pokemon/exeggcute.png', '/uploads/pokemon/exeggcute_icon.png', '/uploads/pokemon/exeggcute.gif', 'Estos seis huevos se comunican por telepatía. Si se\nseparan, se pueden reunir rápidamente.'),
(103, 103, 'exeggutor', '/uploads/pokemon/exeggutor.png', '/uploads/pokemon/exeggutor_icon.png', '/uploads/pokemon/exeggutor.gif', 'Sus tres cabezas piensan de forma independiente.\nSin embargo, son amigas y no suelen discutir nunca.'),
(104, 104, 'cubone', '/uploads/pokemon/cubone.png', '/uploads/pokemon/cubone_icon.png', '/uploads/pokemon/cubone.gif', 'Lleva puesto el cráneo de su madre. Cuando se siente\nsolo se pone a gritar muy fuerte.'),
(105, 105, 'marowak', '/uploads/pokemon/marowak.png', '/uploads/pokemon/marowak_icon.png', '/uploads/pokemon/marowak.gif', 'Es pequeño y siempre ha sido muy débil. Cuando\nempezó a usar huesos, se volvió más violento.'),
(106, 106, 'hitmonlee', '/uploads/pokemon/hitmonlee.png', '/uploads/pokemon/hitmonlee_icon.png', '/uploads/pokemon/hitmonlee.gif', 'Encoge y estira las patas a su antojo. Cuando las\nestira, es capaz de propinar una buena patada al\nenemigo.'),
(107, 107, 'hitmonchan', '/uploads/pokemon/hitmonchan.png', '/uploads/pokemon/hitmonchan_icon.png', '/uploads/pokemon/hitmonchan.gif', 'Los potentes golpes de sus brazos pueden pulverizar\nel hormigón. Descansa tras luchar tres minutos.'),
(108, 108, 'lickitung', '/uploads/pokemon/lickitung.png', '/uploads/pokemon/lickitung_icon.png', '/uploads/pokemon/lickitung.gif', 'Su larga lengua, recubierta de saliva pegajosa, se\npega a todo, por lo que es muy útil.'),
(109, 109, 'koffing', '/uploads/pokemon/koffing.png', '/uploads/pokemon/koffing_icon.png', '/uploads/pokemon/koffing.gif', 'Tiene forma de globo y es muy ligero. Está compuesto\npor gases tóxicos y apesta.'),
(110, 110, 'weezing', '/uploads/pokemon/weezing.png', '/uploads/pokemon/weezing_icon.png', '/uploads/pokemon/weezing.gif', 'Si uno de los gemelos Koffing se infla, el otro se\ndesinfla. Mezclan constantemente sus venenosos\ngases.'),
(111, 111, 'rhyhorn', '/uploads/pokemon/rhyhorn.png', '/uploads/pokemon/rhyhorn_icon.png', '/uploads/pokemon/rhyhorn.gif', 'Es muy fuerte, pero no especialmente listo. Es capaz\nde derribar rascacielos usando Placaje varias veces.'),
(112, 112, 'rhydon', '/uploads/pokemon/rhydon.png', '/uploads/pokemon/rhydon_icon.png', '/uploads/pokemon/rhydon.gif', 'La piel le sirve de escudo protector. Puede vivir en\nlava líquida a 2000 °C de temperatura.'),
(113, 113, 'chansey', '/uploads/pokemon/chansey.png', '/uploads/pokemon/chansey_icon.png', '/uploads/pokemon/chansey.gif', 'Se dice que reparte felicidad. Se caracteriza por su\ncompasión y reparte sus huevos entre la gente herida.'),
(114, 114, 'tangela', '/uploads/pokemon/tangela.png', '/uploads/pokemon/tangela_icon.png', '/uploads/pokemon/tangela.gif', 'Se camufla con la multitud de lianas que envuelven su\ncuerpo y que no dejan de crecer a lo largo de toda su\nvida.'),
(115, 115, 'kangaskhan', '/uploads/pokemon/kangaskhan.png', '/uploads/pokemon/kangaskhan_icon.png', '/uploads/pokemon/kangaskhan.gif', 'Lleva a su cría en la bolsa de su panza. Solo deja que\nsu cría salga a jugar cuando no siente peligro.'),
(116, 116, 'horsea', '/uploads/pokemon/horsea.png', '/uploads/pokemon/horsea_icon.png', '/uploads/pokemon/horsea.gif', 'Es famoso por derribar a bichos voladores lanzando\ntinta desde la superficie del agua.'),
(117, 117, 'seadra', '/uploads/pokemon/seadra.png', '/uploads/pokemon/seadra_icon.png', '/uploads/pokemon/seadra.gif', 'Las afiladas púas que le recubren el cuerpo se le\nerizan y pueden causar el debilitamiento con solo\ntocarlo.'),
(118, 118, 'goldeen', '/uploads/pokemon/goldeen.png', '/uploads/pokemon/goldeen_icon.png', '/uploads/pokemon/goldeen.gif', 'Nada a una velocidad de cinco nudos. Si siente\npeligro, golpea con su afilado cuerno.'),
(119, 119, 'seaking', '/uploads/pokemon/seaking.png', '/uploads/pokemon/seaking_icon.png', '/uploads/pokemon/seaking.gif', 'En otoño, cuando se reproducen, se les puede ver\nnadando con energía por ríos y arroyos.'),
(120, 120, 'staryu', '/uploads/pokemon/staryu.png', '/uploads/pokemon/staryu_icon.png', '/uploads/pokemon/staryu.gif', 'Aunque sus brazos se rompan podrán regenerarse,\nsiempre y cuando su núcleo siga intacto.'),
(121, 121, 'starmie', '/uploads/pokemon/starmie.png', '/uploads/pokemon/starmie_icon.png', '/uploads/pokemon/starmie.gif', 'Su núcleo central brilla con los colores del arcoíris.\nPara algunos tiene el valor de una gema.'),
(122, 122, 'mr-mime', '/uploads/pokemon/mr-mime.png', '/uploads/pokemon/mr-mime_icon.png', '/uploads/pokemon/mr-mime.gif', 'Para repeler ataques, solidifica el aire y crea muros\ninvisibles con emanaciones de sus dedos.'),
(123, 123, 'scyther', '/uploads/pokemon/scyther.png', '/uploads/pokemon/scyther_icon.png', '/uploads/pokemon/scyther.gif', 'Destroza a su presa con las guadañas que tiene.\nNo es común que use las alas para volar.'),
(124, 124, 'jynx', '/uploads/pokemon/jynx.png', '/uploads/pokemon/jynx_icon.png', '/uploads/pokemon/jynx.gif', 'Camina moviendo las caderas de forma llamativa.\nPuede hacer que la gente baile a su ritmo.'),
(125, 125, 'electabuzz', '/uploads/pokemon/electabuzz.png', '/uploads/pokemon/electabuzz_icon.png', '/uploads/pokemon/electabuzz.gif', 'Por la superficie de su piel corre la electricidad. En la\noscuridad, su cuerpo se torna blanquecino.'),
(126, 126, 'magmar', '/uploads/pokemon/magmar.png', '/uploads/pokemon/magmar_icon.png', '/uploads/pokemon/magmar.gif', 'A este Pokémon se lo encontraron cerca de un volcán.\nEsta criatura ígnea tiene una temperatura corporal de\nunos 1200 °C.'),
(127, 127, 'pinsir', '/uploads/pokemon/pinsir.png', '/uploads/pokemon/pinsir_icon.png', '/uploads/pokemon/pinsir.gif', 'Atrapa presas con sus pinzas hasta que las parte en\ndos. Lanza lejos lo que no puede quebrar.'),
(128, 128, 'tauros', '/uploads/pokemon/tauros.png', '/uploads/pokemon/tauros_icon.png', '/uploads/pokemon/tauros.gif', 'Después de animarse a luchar fustigándose con sus\ntres colas, carga a toda velocidad.'),
(129, 129, 'magikarp', '/uploads/pokemon/magikarp.png', '/uploads/pokemon/magikarp_icon.png', '/uploads/pokemon/magikarp.gif', 'No es precisamente rápido ni fuerte. Es el Pokémon\nmás debilucho y simplón de todos los que hay.'),
(130, 130, 'gyarados', '/uploads/pokemon/gyarados.png', '/uploads/pokemon/gyarados_icon.png', '/uploads/pokemon/gyarados.gif', 'En la literatura antigua se dice que un Gyarados\nrebosante de violencia arrasó un poblado.'),
(131, 131, 'lapras', '/uploads/pokemon/lapras.png', '/uploads/pokemon/lapras_icon.png', '/uploads/pokemon/lapras.gif', 'Son buenos de corazón. Muchos fueron capturados\npor ser tan pacíficos. Ahora hay muchos menos.'),
(132, 132, 'ditto', '/uploads/pokemon/ditto.png', '/uploads/pokemon/ditto_icon.png', '/uploads/pokemon/ditto.gif', 'Puede alterar por completo su estructura celular para\nemular cualquier objeto que vea.'),
(133, 133, 'eevee', '/uploads/pokemon/eevee.png', '/uploads/pokemon/eevee_icon.png', '/uploads/pokemon/eevee.gif', 'Un extraño Pokémon que se adapta a los entornos\nmás hostiles gracias a sus diferentes evoluciones.'),
(134, 134, 'vaporeon', '/uploads/pokemon/vaporeon.png', '/uploads/pokemon/vaporeon_icon.png', '/uploads/pokemon/vaporeon.gif', 'Prefiere las bellas costas. Con células parecidas al\nagua, podría fundirse en la misma.'),
(135, 135, 'jolteon', '/uploads/pokemon/jolteon.png', '/uploads/pokemon/jolteon_icon.png', '/uploads/pokemon/jolteon.gif', 'Todos los pelos de su cuerpo se ponen de punta si\nempieza a cargarse de electricidad.'),
(136, 136, 'flareon', '/uploads/pokemon/flareon.png', '/uploads/pokemon/flareon_icon.png', '/uploads/pokemon/flareon.gif', 'Almacena llamas en su cuerpo, que alcanza una\ntemperatura de 900 °C antes de un combate.'),
(137, 137, 'porygon', '/uploads/pokemon/porygon.png', '/uploads/pokemon/porygon_icon.png', '/uploads/pokemon/porygon.gif', 'Pokémon creado por el hombre tras muchas\ninvestigaciones. Sus habilidades son básicas.'),
(138, 138, 'omanyte', '/uploads/pokemon/omanyte.png', '/uploads/pokemon/omanyte_icon.png', '/uploads/pokemon/omanyte.gif', 'Pokémon prehistórico que vivió en el océano\nprimordial. Para nadar se valía de sus 10 tentáculos.'),
(139, 139, 'omastar', '/uploads/pokemon/omastar.png', '/uploads/pokemon/omastar_icon.png', '/uploads/pokemon/omastar.gif', 'Tiene los tentáculos tan desarrollados que le sirven de\nmanos y pies. Con ellos atrapa a su presa y le da un\nbocado.'),
(140, 140, 'kabuto', '/uploads/pokemon/kabuto.png', '/uploads/pokemon/kabuto_icon.png', '/uploads/pokemon/kabuto.gif', 'Se cree que habitó las playas hace 300 millones de\naños. Se protege con una dura concha.'),
(141, 141, 'kabutops', '/uploads/pokemon/kabutops.png', '/uploads/pokemon/kabutops_icon.png', '/uploads/pokemon/kabutops.gif', 'Repliega sus extremidades en el agua para hacerse\nmás compacto, y mueve su concha para nadar rápido.'),
(142, 142, 'aerodactyl', '/uploads/pokemon/aerodactyl.png', '/uploads/pokemon/aerodactyl_icon.png', '/uploads/pokemon/aerodactyl.gif', 'Se regeneró a partir de material genético de un\ndinosaurio encontrado en ámbar. Cuando vuela emite\nescandalosos alaridos.'),
(143, 143, 'snorlax', '/uploads/pokemon/snorlax.png', '/uploads/pokemon/snorlax_icon.png', '/uploads/pokemon/snorlax.gif', 'No se encuentra satisfecho hasta que no se come\n400 kg de comida cada día. Cuando acaba de comer,\nse queda dormido.'),
(144, 144, 'articuno', '/uploads/pokemon/articuno.png', '/uploads/pokemon/articuno_icon.png', '/uploads/pokemon/articuno.gif', 'Legendario Pokémon pájaro capaz de generar\nventiscas congelando la humedad del aire.'),
(145, 145, 'zapdos', '/uploads/pokemon/zapdos.png', '/uploads/pokemon/zapdos_icon.png', '/uploads/pokemon/zapdos.gif', 'Es un legendario pájaro Pokémon. Dicen que aparece\nentre las nubes lanzando enormes rayos brillantes.'),
(146, 146, 'moltres', '/uploads/pokemon/moltres.png', '/uploads/pokemon/moltres_icon.png', '/uploads/pokemon/moltres.gif', 'Es más conocido como el legendario pájaro de fuego.\nCon cada aleteo crea brillantes llamas.'),
(147, 147, 'dratini', '/uploads/pokemon/dratini.png', '/uploads/pokemon/dratini_icon.png', '/uploads/pokemon/dratini.gif', 'Se le llama el Pokémon Espejismo porque son muy\npocos los que lo han visto. Se encontró su muda.'),
(148, 148, 'dragonair', '/uploads/pokemon/dragonair.png', '/uploads/pokemon/dragonair_icon.png', '/uploads/pokemon/dragonair.gif', 'Sus cristalinos orbes parecen darle al Pokémon el\npoder de controlar el clima libremente.'),
(149, 149, 'dragonite', '/uploads/pokemon/dragonite.png', '/uploads/pokemon/dragonite_icon.png', '/uploads/pokemon/dragonite.gif', 'A pesar del tamaño que tiene y de lo pesado que es,\npuede volar. Es capaz de dar la vuelta al mundo en\nsolo 16 horas.'),
(150, 150, 'mewtwo', '/uploads/pokemon/mewtwo.png', '/uploads/pokemon/mewtwo_icon.png', '/uploads/pokemon/mewtwo.gif', 'Fue creado por un científico tras años de horribles\nexperimentos de ingeniería genética.'),
(151, 151, 'mew', '/uploads/pokemon/mew.png', '/uploads/pokemon/mew_icon.png', '/uploads/pokemon/mew.gif', 'Varios científicos lo consideran el antecesor de los\nPokémon porque usa todo tipo de movimientos.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Pokemon_Tipo`
--

CREATE TABLE `Pokemon_Tipo` (
  `ID_Pokemon` int NOT NULL,
  `ID_Tipo` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `Pokemon_Tipo`
--

INSERT INTO `Pokemon_Tipo` (`ID_Pokemon`, `ID_Tipo`) VALUES
(1, 1),
(2, 1),
(3, 1),
(43, 1),
(44, 1),
(45, 1),
(46, 1),
(47, 1),
(69, 1),
(70, 1),
(71, 1),
(102, 1),
(103, 1),
(114, 1),
(1, 2),
(2, 2),
(3, 2),
(13, 2),
(14, 2),
(15, 2),
(23, 2),
(24, 2),
(29, 2),
(30, 2),
(31, 2),
(32, 2),
(33, 2),
(34, 2),
(41, 2),
(42, 2),
(43, 2),
(44, 2),
(45, 2),
(48, 2),
(49, 2),
(69, 2),
(70, 2),
(71, 2),
(72, 2),
(73, 2),
(88, 2),
(89, 2),
(92, 2),
(93, 2),
(94, 2),
(109, 2),
(110, 2),
(4, 3),
(5, 3),
(6, 3),
(37, 3),
(38, 3),
(58, 3),
(59, 3),
(77, 3),
(78, 3),
(126, 3),
(136, 3),
(146, 3),
(6, 4),
(12, 4),
(16, 4),
(17, 4),
(18, 4),
(21, 4),
(22, 4),
(41, 4),
(42, 4),
(83, 4),
(84, 4),
(85, 4),
(123, 4),
(130, 4),
(142, 4),
(144, 4),
(145, 4),
(146, 4),
(149, 4),
(7, 5),
(8, 5),
(9, 5),
(54, 5),
(55, 5),
(60, 5),
(61, 5),
(62, 5),
(72, 5),
(73, 5),
(79, 5),
(80, 5),
(86, 5),
(87, 5),
(90, 5),
(91, 5),
(98, 5),
(99, 5),
(116, 5),
(117, 5),
(118, 5),
(119, 5),
(120, 5),
(121, 5),
(129, 5),
(130, 5),
(131, 5),
(134, 5),
(138, 5),
(139, 5),
(140, 5),
(141, 5),
(10, 6),
(11, 6),
(12, 6),
(13, 6),
(14, 6),
(15, 6),
(46, 6),
(47, 6),
(48, 6),
(49, 6),
(123, 6),
(127, 6),
(16, 7),
(17, 7),
(18, 7),
(19, 7),
(20, 7),
(21, 7),
(22, 7),
(39, 7),
(40, 7),
(52, 7),
(53, 7),
(83, 7),
(84, 7),
(85, 7),
(108, 7),
(113, 7),
(115, 7),
(128, 7),
(132, 7),
(133, 7),
(137, 7),
(143, 7),
(25, 8),
(26, 8),
(81, 8),
(82, 8),
(100, 8),
(101, 8),
(125, 8),
(135, 8),
(145, 8),
(27, 9),
(28, 9),
(31, 9),
(34, 9),
(50, 9),
(51, 9),
(74, 9),
(75, 9),
(76, 9),
(95, 9),
(104, 9),
(105, 9),
(111, 9),
(112, 9),
(35, 10),
(36, 10),
(39, 10),
(40, 10),
(122, 10),
(56, 11),
(57, 11),
(62, 11),
(66, 11),
(67, 11),
(68, 11),
(106, 11),
(107, 11),
(63, 12),
(64, 12),
(65, 12),
(79, 12),
(80, 12),
(96, 12),
(97, 12),
(102, 12),
(103, 12),
(121, 12),
(122, 12),
(124, 12),
(150, 12),
(151, 12),
(74, 13),
(75, 13),
(76, 13),
(95, 13),
(111, 13),
(112, 13),
(138, 13),
(139, 13),
(140, 13),
(141, 13),
(142, 13),
(81, 14),
(82, 14),
(87, 15),
(91, 15),
(124, 15),
(131, 15),
(144, 15),
(92, 16),
(93, 16),
(94, 16),
(147, 17),
(148, 17),
(149, 17);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Tipos`
--

CREATE TABLE `Tipos` (
  `ID_Tipos` int NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Icono` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `Tipos`
--

INSERT INTO `Tipos` (`ID_Tipos`, `Nombre`, `Icono`) VALUES
(1, 'grass', '/uploads/tipos/grass.png'),
(2, 'poison', '/uploads/tipos/poison.png'),
(3, 'fire', '/uploads/tipos/fire.png'),
(4, 'flying', '/uploads/tipos/flying.png'),
(5, 'water', '/uploads/tipos/water.png'),
(6, 'bug', '/uploads/tipos/bug.png'),
(7, 'normal', '/uploads/tipos/normal.png'),
(8, 'electric', '/uploads/tipos/electric.png'),
(9, 'ground', '/uploads/tipos/ground.png'),
(10, 'fairy', '/uploads/tipos/fairy.png'),
(11, 'fighting', '/uploads/tipos/fighting.png'),
(12, 'psychic', '/uploads/tipos/psychic.png'),
(13, 'rock', '/uploads/tipos/rock.png'),
(14, 'steel', '/uploads/tipos/steel.png'),
(15, 'ice', '/uploads/tipos/ice.png'),
(16, 'ghost', '/uploads/tipos/ghost.png'),
(17, 'dragon', '/uploads/tipos/dragon.png'),
(18, 'dark', '/uploads/tipos/dark.png'),
(19, 'stellar', NULL),
(20, 'unknown', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Tipo_Eficaz`
--

CREATE TABLE `Tipo_Eficaz` (
  `ID_Tipo_Origen` int NOT NULL,
  `ID_Tipo_Destino` int NOT NULL,
  `Multiplicador` decimal(3,2) NOT NULL DEFAULT '1.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `Tipo_Eficaz`
--

INSERT INTO `Tipo_Eficaz` (`ID_Tipo_Origen`, `ID_Tipo_Destino`, `Multiplicador`) VALUES
(1, 1, 0.50),
(1, 2, 0.50),
(1, 3, 0.50),
(1, 4, 0.50),
(1, 5, 2.00),
(1, 6, 0.50),
(1, 9, 2.00),
(1, 13, 2.00),
(1, 14, 0.50),
(1, 17, 0.50),
(2, 1, 2.00),
(2, 2, 0.50),
(2, 9, 0.50),
(2, 10, 2.00),
(2, 13, 0.50),
(2, 14, 0.00),
(2, 16, 0.50),
(3, 1, 2.00),
(3, 3, 0.50),
(3, 5, 0.50),
(3, 6, 2.00),
(3, 13, 0.50),
(3, 14, 2.00),
(3, 15, 2.00),
(3, 17, 0.50),
(4, 1, 2.00),
(4, 6, 2.00),
(4, 8, 0.50),
(4, 11, 2.00),
(4, 13, 0.50),
(4, 14, 0.50),
(5, 1, 0.50),
(5, 3, 2.00),
(5, 5, 0.50),
(5, 9, 2.00),
(5, 13, 2.00),
(5, 17, 0.50),
(6, 1, 2.00),
(6, 2, 0.50),
(6, 3, 0.50),
(6, 4, 0.50),
(6, 10, 0.50),
(6, 11, 0.50),
(6, 12, 2.00),
(6, 14, 0.50),
(6, 16, 0.50),
(6, 18, 2.00),
(7, 13, 0.50),
(7, 14, 0.50),
(7, 16, 0.00),
(8, 1, 0.50),
(8, 4, 2.00),
(8, 5, 2.00),
(8, 8, 0.50),
(8, 9, 0.00),
(8, 17, 0.50),
(9, 1, 0.50),
(9, 2, 2.00),
(9, 3, 2.00),
(9, 4, 0.00),
(9, 6, 0.50),
(9, 8, 2.00),
(9, 13, 2.00),
(9, 14, 2.00),
(10, 2, 0.50),
(10, 3, 0.50),
(10, 11, 2.00),
(10, 14, 0.50),
(10, 17, 2.00),
(10, 18, 2.00),
(11, 2, 0.50),
(11, 4, 0.50),
(11, 6, 0.50),
(11, 7, 2.00),
(11, 10, 0.50),
(11, 12, 0.50),
(11, 13, 2.00),
(11, 14, 2.00),
(11, 15, 2.00),
(11, 16, 0.00),
(11, 18, 2.00),
(12, 2, 2.00),
(12, 11, 2.00),
(12, 12, 0.50),
(12, 14, 0.50),
(12, 18, 0.00),
(13, 3, 2.00),
(13, 4, 2.00),
(13, 6, 2.00),
(13, 9, 0.50),
(13, 11, 0.50),
(13, 14, 0.50),
(13, 15, 2.00),
(14, 3, 0.50),
(14, 5, 0.50),
(14, 8, 0.50),
(14, 10, 2.00),
(14, 13, 2.00),
(14, 14, 0.50),
(14, 15, 2.00),
(15, 1, 2.00),
(15, 3, 0.50),
(15, 4, 2.00),
(15, 5, 0.50),
(15, 9, 2.00),
(15, 14, 0.50),
(15, 15, 0.50),
(15, 17, 2.00),
(16, 7, 0.00),
(16, 12, 2.00),
(16, 16, 2.00),
(16, 18, 0.50),
(17, 10, 0.00),
(17, 14, 0.50),
(17, 17, 2.00),
(18, 10, 0.50),
(18, 11, 0.50),
(18, 12, 2.00),
(18, 16, 2.00),
(18, 18, 0.50);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `doctrine_migration_versions`
--
ALTER TABLE `doctrine_migration_versions`
  ADD PRIMARY KEY (`version`);

--
-- Indices de la tabla `Pokemon`
--
ALTER TABLE `Pokemon`
  ADD PRIMARY KEY (`ID_Pokemon`);

--
-- Indices de la tabla `Pokemon_Tipo`
--
ALTER TABLE `Pokemon_Tipo`
  ADD PRIMARY KEY (`ID_Pokemon`,`ID_Tipo`),
  ADD KEY `ID_Tipo` (`ID_Tipo`);

--
-- Indices de la tabla `Tipos`
--
ALTER TABLE `Tipos`
  ADD PRIMARY KEY (`ID_Tipos`),
  ADD UNIQUE KEY `Nombre` (`Nombre`);

--
-- Indices de la tabla `Tipo_Eficaz`
--
ALTER TABLE `Tipo_Eficaz`
  ADD PRIMARY KEY (`ID_Tipo_Origen`,`ID_Tipo_Destino`),
  ADD KEY `ID_Tipo_Destino` (`ID_Tipo_Destino`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `Pokemon`
--
ALTER TABLE `Pokemon`
  MODIFY `ID_Pokemon` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;

--
-- AUTO_INCREMENT de la tabla `Tipos`
--
ALTER TABLE `Tipos`
  MODIFY `ID_Tipos` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `Pokemon_Tipo`
--
ALTER TABLE `Pokemon_Tipo`
  ADD CONSTRAINT `Pokemon_Tipo_ibfk_1` FOREIGN KEY (`ID_Pokemon`) REFERENCES `Pokemon` (`ID_Pokemon`) ON DELETE CASCADE,
  ADD CONSTRAINT `Pokemon_Tipo_ibfk_2` FOREIGN KEY (`ID_Tipo`) REFERENCES `Tipos` (`ID_Tipos`) ON DELETE CASCADE;

--
-- Filtros para la tabla `Tipo_Eficaz`
--
ALTER TABLE `Tipo_Eficaz`
  ADD CONSTRAINT `Tipo_Eficaz_ibfk_1` FOREIGN KEY (`ID_Tipo_Origen`) REFERENCES `Tipos` (`ID_Tipos`) ON DELETE CASCADE,
  ADD CONSTRAINT `Tipo_Eficaz_ibfk_2` FOREIGN KEY (`ID_Tipo_Destino`) REFERENCES `Tipos` (`ID_Tipos`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
