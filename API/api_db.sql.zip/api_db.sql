-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Servidor: db:3306
-- Tiempo de generación: 21-05-2025 a las 20:12:19
-- Versión del servidor: 8.0.42
-- Versión de PHP: 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `api_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `doctrine_migration_versions`
--

CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Volcado de datos para la tabla `doctrine_migration_versions`
--

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20250422100852', '2025-04-22 10:09:16', 254),
('DoctrineMigrations\\Version20250422101615', '2025-04-22 10:16:24', 106);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Equipo`
--

CREATE TABLE `Equipo` (
  `ID_Equipo` int NOT NULL,
  `ID_Usuario` int NOT NULL,
  `Numero_Equipo` int NOT NULL,
  `Nombre_Equipo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `Equipo`
--

INSERT INTO `Equipo` (`ID_Equipo`, `ID_Usuario`, `Numero_Equipo`, `Nombre_Equipo`) VALUES
(1, 1, 1, 'Equipo de prueba'),
(2, 1, 2, 'Starter Squad'),
(3, 3, 3, 'Mischief Makers'),
(9, 1, 5, 'Equipo de prueba');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Equipos_Pokemon`
--

CREATE TABLE `Equipos_Pokemon` (
  `ID_Equipo` int NOT NULL,
  `ID_Pokemon` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `Equipos_Pokemon`
--

INSERT INTO `Equipos_Pokemon` (`ID_Equipo`, `ID_Pokemon`) VALUES
(1, 1),
(2, 1),
(9, 1),
(1, 4),
(2, 4),
(9, 4),
(1, 7),
(2, 7),
(9, 7),
(3, 25),
(3, 39),
(3, 94);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Pokemon`
--

CREATE TABLE `Pokemon` (
  `ID_Pokemon` int NOT NULL,
  `ID_Api` int NOT NULL,
  `Nombre` varchar(255) NOT NULL,
  `Imagen` varchar(255) DEFAULT NULL,
  `Imagen 2D` varchar(255) DEFAULT NULL,
  `Gif` varchar(255) DEFAULT NULL,
  `Descripcion` text,
  `Evoluciona` int DEFAULT NULL,
  `Altura` int DEFAULT NULL,
  `Peso` int DEFAULT NULL,
  `Habilidades` text,
  `HabilidadOculta` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Especie` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Generacion` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `Pokemon`
--

INSERT INTO `Pokemon` (`ID_Pokemon`, `ID_Api`, `Nombre`, `Imagen`, `Imagen 2D`, `Gif`, `Descripcion`, `Evoluciona`, `Altura`, `Peso`, `Habilidades`, `HabilidadOculta`, `Especie`, `Generacion`) VALUES
(1, 1, 'bulbasaur', '/uploads/pokemon/bulbasaur.png', '/uploads/pokemon/2d/bulbasaur.png', '/uploads/pokemon/gif/bulbasaur.gif', 'Una rara semilla le fue plantada en el lomo al nacer.\nLa planta brota y crece con este Pokémon.', NULL, 7, 69, 'overgrow, chlorophyll', 'chlorophyll', 'Pokémon Semilla', 'generation-i'),
(2, 2, 'ivysaur', '/uploads/pokemon/ivysaur.png', '/uploads/pokemon/2d/ivysaur.png', '/uploads/pokemon/gif/ivysaur.gif', 'Este Pokémon tiene un bulbo en el lomo. Dicen que,\nal absorber nutrientes, el bulbo se transforma en una\nflor grande.', 1, 10, 130, 'overgrow, chlorophyll', 'chlorophyll', 'Pokémon Semilla', 'generation-i'),
(3, 3, 'venusaur', '/uploads/pokemon/venusaur.png', '/uploads/pokemon/2d/venusaur.png', '/uploads/pokemon/gif/venusaur.gif', 'Llena su cuerpo de energía con los rayos solares que\ncaptan los anchos pétalos de su flor.', 2, 20, 1000, 'overgrow, chlorophyll', 'chlorophyll', 'Pokémon Semilla', 'generation-i'),
(4, 4, 'charmander', '/uploads/pokemon/charmander.png', '/uploads/pokemon/2d/charmander.png', '/uploads/pokemon/gif/charmander.gif', 'La llama de su cola indica la fuerza vital de\nCharmander. Será brillante si está sano.', NULL, 6, 85, 'blaze, solar-power', 'solar-power', 'Pokémon Lagartija', 'generation-i'),
(5, 5, 'charmeleon', '/uploads/pokemon/charmeleon.png', '/uploads/pokemon/2d/charmeleon.png', '/uploads/pokemon/gif/charmeleon.gif', 'Suele usar la cola para derribar a su rival. Cuando lo\ntira, se vale de sus afiladas garras para acabar con él.', 4, 11, 190, 'blaze, solar-power', 'solar-power', 'Pokémon Llama', 'generation-i'),
(6, 6, 'charizard', '/uploads/pokemon/charizard.png', '/uploads/pokemon/2d/charizard.png', '/uploads/pokemon/gif/charizard.gif', 'Cuando lanza una descarga de fuego supercaliente, la\nroja llama de su cola brilla más intensamente.', 5, 17, 905, 'blaze, solar-power', 'solar-power', 'Pokémon Llama', 'generation-i'),
(7, 7, 'squirtle', '/uploads/pokemon/squirtle.png', '/uploads/pokemon/2d/squirtle.png', '/uploads/pokemon/gif/squirtle.gif', 'Se protege con su caparazón y luego contraataca\nlanzando agua a presión cuando tiene oportunidad.', NULL, 5, 90, 'torrent, rain-dish', 'rain-dish', 'Pokémon Tortuguita', 'generation-i'),
(8, 8, 'wartortle', '/uploads/pokemon/wartortle.png', '/uploads/pokemon/2d/wartortle.png', '/uploads/pokemon/gif/wartortle.gif', 'Si es golpeado, esconderá su cabeza. Aun así, su cola\npuede seguir golpeando.', 7, 10, 225, 'torrent, rain-dish', 'rain-dish', 'Pokémon Tortuga', 'generation-i'),
(9, 9, 'blastoise', '/uploads/pokemon/blastoise.png', '/uploads/pokemon/2d/blastoise.png', '/uploads/pokemon/gif/blastoise.gif', 'Para acabar con su enemigo, lo aplasta con el peso de\nsu cuerpo. En momentos de apuro, se esconde en el\ncaparazón.', 8, 16, 855, 'torrent, rain-dish', 'rain-dish', 'Pokémon Armazón', 'generation-i'),
(10, 10, 'caterpie', '/uploads/pokemon/caterpie.png', '/uploads/pokemon/2d/caterpie.png', '/uploads/pokemon/gif/caterpie.gif', 'Para protegerse despide un hedor horrible de sus\nantenas, con el que repele a sus enemigos.', NULL, 3, 29, 'shield-dust, run-away', 'run-away', 'Pokémon Gusano', 'generation-i'),
(11, 11, 'metapod', '/uploads/pokemon/metapod.png', '/uploads/pokemon/2d/metapod.png', '/uploads/pokemon/gif/metapod.gif', 'Su frágil cuerpo está recubierto de una coraza dura\ncomo el acero. Permanece quieto en su desarrollo.', 10, 7, 99, 'shed-skin', NULL, 'Pokémon Capullo', 'generation-i'),
(12, 12, 'butterfree', '/uploads/pokemon/butterfree.png', '/uploads/pokemon/2d/butterfree.png', '/uploads/pokemon/gif/butterfree.gif', 'Adora el néctar de las flores. Puede localizar hasta las\nmás pequeñas cantidades de polen.', 11, 11, 320, 'compound-eyes, tinted-lens', 'tinted-lens', 'Pokémon Mariposa', 'generation-i'),
(13, 13, 'weedle', '/uploads/pokemon/weedle.png', '/uploads/pokemon/2d/weedle.png', '/uploads/pokemon/gif/weedle.gif', 'Suele habitar bosques y praderas. Tiene un afilado y\nvenenoso aguijón de unos 5 cm encima de la cabeza.', NULL, 3, 32, 'shield-dust, run-away', 'run-away', 'Pokémon Oruga', 'generation-i'),
(14, 14, 'kakuna', '/uploads/pokemon/kakuna.png', '/uploads/pokemon/2d/kakuna.png', '/uploads/pokemon/gif/kakuna.gif', 'Casi incapaz de moverse, este Pokémon solo puede\nendurecer su caparazón para protegerse.', 13, 6, 100, 'shed-skin', NULL, 'Pokémon Capullo', 'generation-i'),
(15, 15, 'beedrill', '/uploads/pokemon/beedrill.png', '/uploads/pokemon/2d/beedrill.png', '/uploads/pokemon/gif/beedrill.gif', 'Tiene 3 aguijones venenosos en sus patas y cola.\nSuelen pinchar a sus enemigos repetidas veces.', 14, 10, 295, 'swarm, sniper', 'sniper', 'Pokémon Abeja Veneno', 'generation-i'),
(16, 16, 'pidgey', '/uploads/pokemon/pidgey.png', '/uploads/pokemon/2d/pidgey.png', '/uploads/pokemon/gif/pidgey.gif', 'Muy común en bosques y selvas. Aletea al nivel del\nsuelo para levantar la gravilla.', NULL, 3, 18, 'keen-eye, tangled-feet, big-pecks', 'big-pecks', 'Pokémon Pajarito', 'generation-i'),
(17, 17, 'pidgeotto', '/uploads/pokemon/pidgeotto.png', '/uploads/pokemon/2d/pidgeotto.png', '/uploads/pokemon/gif/pidgeotto.gif', 'Tiene unas garras desarrolladas. Puede atrapar un\nExeggcute y transportarlo desde una distancia de\ncasi 100 km.', 16, 11, 300, 'keen-eye, tangled-feet, big-pecks', 'big-pecks', 'Pokémon Pájaro', 'generation-i'),
(18, 18, 'pidgeot', '/uploads/pokemon/pidgeot.png', '/uploads/pokemon/2d/pidgeot.png', '/uploads/pokemon/gif/pidgeot.gif', 'Cuando caza, vuela muy deprisa a ras del agua y\nsorprende a inocentes presas como Magikarp.', 17, 15, 395, 'keen-eye, tangled-feet, big-pecks', 'big-pecks', 'Pokémon Pájaro', 'generation-i'),
(19, 19, 'rattata', '/uploads/pokemon/rattata.png', '/uploads/pokemon/2d/rattata.png', '/uploads/pokemon/gif/rattata.gif', 'Vive allí donde haya comida disponible. Busca todo\nel día, sin descanso, algo comestible.', NULL, 3, 35, 'run-away, guts, hustle', 'hustle', 'Pokémon Ratón', 'generation-i'),
(20, 20, 'raticate', '/uploads/pokemon/raticate.png', '/uploads/pokemon/2d/raticate.png', '/uploads/pokemon/gif/raticate.gif', 'Lima sus colmillos royendo objetos duros. Con ellos\npuede destruir incluso paredes de hormigón.', 19, 7, 185, 'run-away, guts, hustle', 'hustle', 'Pokémon Ratón', 'generation-i'),
(21, 21, 'spearow', '/uploads/pokemon/spearow.png', '/uploads/pokemon/2d/spearow.png', '/uploads/pokemon/gif/spearow.gif', 'Muy protector de su territorio, mueve sus cortas alas\nsin descanso para lanzarse a toda velocidad.', NULL, 3, 20, 'keen-eye, sniper', 'sniper', 'Pokémon Pajarito', 'generation-i'),
(22, 22, 'fearow', '/uploads/pokemon/fearow.png', '/uploads/pokemon/2d/fearow.png', '/uploads/pokemon/gif/fearow.gif', 'Con sus enormes y magníficas alas, puede seguir\nvolando sin tener que aterrizar para descansar.', 21, 12, 380, 'keen-eye, sniper', 'sniper', 'Pokémon Pico', 'generation-i'),
(23, 23, 'ekans', '/uploads/pokemon/ekans.png', '/uploads/pokemon/2d/ekans.png', '/uploads/pokemon/gif/ekans.gif', 'Cuanto más viejo, más crece este Pokémon. Por la\nnoche, descansa en las ramas de los árboles.', NULL, 20, 69, 'intimidate, shed-skin, unnerve', 'unnerve', 'Pokémon Serpiente', 'generation-i'),
(24, 24, 'arbok', '/uploads/pokemon/arbok.png', '/uploads/pokemon/2d/arbok.png', '/uploads/pokemon/gif/arbok.gif', 'El dibujo que tiene en la panza aterroriza. Los rivales\nmás débiles salen huyendo al verlo.', 23, 35, 650, 'intimidate, shed-skin, unnerve', 'unnerve', 'Pokémon Cobra', 'generation-i'),
(25, 25, 'pikachu', '/uploads/pokemon/pikachu.png', '/uploads/pokemon/2d/pikachu.png', '/uploads/pokemon/gif/pikachu.gif', 'Levanta su cola para vigilar los alrededores. A veces,\npuede ser alcanzado por un rayo en esa pose.', NULL, 4, 60, 'static, lightning-rod', 'lightning-rod', 'Pokémon Ratón', 'generation-i'),
(26, 26, 'raichu', '/uploads/pokemon/raichu.png', '/uploads/pokemon/2d/raichu.png', '/uploads/pokemon/gif/raichu.gif', 'Cuando se carga de electricidad, sus músculos se\ntensan y se vuelve más agresivo de lo normal.', 25, 8, 300, 'static, lightning-rod', 'lightning-rod', 'Pokémon Ratón', 'generation-i'),
(27, 27, 'sandshrew', '/uploads/pokemon/sandshrew.png', '/uploads/pokemon/2d/sandshrew.png', '/uploads/pokemon/gif/sandshrew.gif', 'Este Pokémon permanece bajo tierra. Si se siente\namenazado, se enrosca para defenderse.', NULL, 6, 120, 'sand-veil, sand-rush', 'sand-rush', 'Pokémon Ratón', 'generation-i'),
(28, 28, 'sandslash', '/uploads/pokemon/sandslash.png', '/uploads/pokemon/2d/sandslash.png', '/uploads/pokemon/gif/sandslash.gif', 'Si cava a gran velocidad, puede que se le caigan las\ngarras y púas. Vuelven a crecerle en un día.', 27, 10, 295, 'sand-veil, sand-rush', 'sand-rush', 'Pokémon Ratón', 'generation-i'),
(29, 29, 'nidoran-f', '/uploads/pokemon/nidoran-f.png', '/uploads/pokemon/2d/nidoran-f.png', '/uploads/pokemon/gif/nidoran-f.gif', 'Aunque pequeñas, sus venenosas púas son muy\npeligrosas. Tienen un cuerno más pequeño que\nlos machos.', NULL, 4, 70, 'poison-point, rivalry, hustle', 'hustle', 'Pokémon Pin Veneno', 'generation-i'),
(30, 30, 'nidorina', '/uploads/pokemon/nidorina.png', '/uploads/pokemon/2d/nidorina.png', '/uploads/pokemon/gif/nidorina.gif', 'Tiene un carácter afable. Emite ondas ultrasónicas\npara confundir al enemigo.', 29, 8, 200, 'poison-point, rivalry, hustle', 'hustle', 'Pokémon Pin Veneno', 'generation-i'),
(31, 31, 'nidoqueen', '/uploads/pokemon/nidoqueen.png', '/uploads/pokemon/2d/nidoqueen.png', '/uploads/pokemon/gif/nidoqueen.gif', 'Usa su cuerpo duro y escamoso para sellar la entrada\na su madriguera y protegerse de los depredadores.', 30, 13, 600, 'poison-point, rivalry, sheer-force', 'sheer-force', 'Pokémon Taladro', 'generation-i'),
(32, 32, 'nidoran-m', '/uploads/pokemon/nidoran-m.png', '/uploads/pokemon/2d/nidoran-m.png', '/uploads/pokemon/gif/nidoran-m.gif', 'Saca las orejas por encima de la hierba para explorar\nel territorio. Le protege su cuerno venenoso.', NULL, 5, 90, 'poison-point, rivalry, hustle', 'hustle', 'Pokémon Pin Veneno', 'generation-i'),
(33, 33, 'nidorino', '/uploads/pokemon/nidorino.png', '/uploads/pokemon/2d/nidorino.png', '/uploads/pokemon/gif/nidorino.gif', 'Levanta sus grandes orejas para vigilar. Si detecta\nalgo, atacará de inmediato.', 32, 9, 195, 'poison-point, rivalry, hustle', 'hustle', 'Pokémon Pin Veneno', 'generation-i'),
(34, 34, 'nidoking', '/uploads/pokemon/nidoking.png', '/uploads/pokemon/2d/nidoking.png', '/uploads/pokemon/gif/nidoking.gif', 'Es fácil reconocerlo por tener una dura piel y un gran\ncuerno lleno de peligrosísimo veneno.', 33, 14, 620, 'poison-point, rivalry, sheer-force', 'sheer-force', 'Pokémon Taladro', 'generation-i'),
(35, 35, 'clefairy', '/uploads/pokemon/clefairy.png', '/uploads/pokemon/2d/clefairy.png', '/uploads/pokemon/gif/clefairy.gif', 'Se dice que la felicidad llegará a quien vea a un grupo\nde Clefairy bailando a la luz de la luna llena.', NULL, 6, 75, 'cute-charm, magic-guard, friend-guard', 'friend-guard', 'Pokémon Hada', 'generation-i'),
(36, 36, 'clefable', '/uploads/pokemon/clefable.png', '/uploads/pokemon/2d/clefable.png', '/uploads/pokemon/gif/clefable.gif', 'Su oído es tan agudo que puede oír una aguja caer a\n1 km. Vive en montañas solitarias.', 35, 13, 400, 'cute-charm, magic-guard, unaware', 'unaware', 'Pokémon Hada', 'generation-i'),
(37, 37, 'vulpix', '/uploads/pokemon/vulpix.png', '/uploads/pokemon/2d/vulpix.png', '/uploads/pokemon/gif/vulpix.gif', 'Cuando nace solo tiene una cola, pero a medida que\ncrece, esta se va dividiendo desde la punta.', NULL, 6, 99, 'flash-fire, drought', 'drought', 'Pokémon Zorro', 'generation-i'),
(38, 38, 'ninetales', '/uploads/pokemon/ninetales.png', '/uploads/pokemon/2d/ninetales.png', '/uploads/pokemon/gif/ninetales.gif', 'Tiene nueve colas y un pelaje de color dorado.\nDicen que este Pokémon llega a vivir 1000 años.', 37, 11, 199, 'flash-fire, drought', 'drought', 'Pokémon Zorro', 'generation-i'),
(39, 39, 'jigglypuff', '/uploads/pokemon/jigglypuff.png', '/uploads/pokemon/2d/jigglypuff.png', '/uploads/pokemon/gif/jigglypuff.gif', 'Cautiva con la mirada a su enemigo y hace que se\nquede profundamente dormido mientras entona una\ndulce melodía.', NULL, 5, 55, 'cute-charm, competitive, friend-guard', 'friend-guard', 'Pokémon Globo', 'generation-i'),
(40, 40, 'wigglytuff', '/uploads/pokemon/wigglytuff.png', '/uploads/pokemon/2d/wigglytuff.png', '/uploads/pokemon/gif/wigglytuff.gif', 'Su piel es tan suave que si dos de ellos se acurrucan\njuntos, no querrán separarse nunca.', 39, 10, 120, 'cute-charm, competitive, frisk', 'frisk', 'Pokémon Globo', 'generation-i'),
(41, 41, 'zubat', '/uploads/pokemon/zubat.png', '/uploads/pokemon/2d/zubat.png', '/uploads/pokemon/gif/zubat.gif', 'Aunque carezca de ojos, puede detectar obstáculos\ncon las ondas ultrasónicas que emite su boca.', NULL, 8, 75, 'inner-focus, infiltrator', 'infiltrator', 'Pokémon Murciélago', 'generation-i'),
(42, 42, 'golbat', '/uploads/pokemon/golbat.png', '/uploads/pokemon/2d/golbat.png', '/uploads/pokemon/gif/golbat.gif', 'Cuando ataque, seguirá chupando energía de su\nvíctima, aunque pese tanto que ya no pueda volar.', 41, 16, 550, 'inner-focus, infiltrator', 'infiltrator', 'Pokémon Murciélago', 'generation-i'),
(43, 43, 'oddish', '/uploads/pokemon/oddish.png', '/uploads/pokemon/2d/oddish.png', '/uploads/pokemon/gif/oddish.gif', 'Durante el día, se agazapa en el frío subsuelo huyendo\ndel sol. La luz de la luna le hace crecer mucho.', NULL, 5, 54, 'chlorophyll, run-away', 'run-away', 'Pokémon Hierbajo', 'generation-i'),
(44, 44, 'gloom', '/uploads/pokemon/gloom.png', '/uploads/pokemon/2d/gloom.png', '/uploads/pokemon/gif/gloom.gif', '¡Huele bastante mal! De todas formas, una de cada\nmil personas aprecian su fétido olor.', 43, 8, 86, 'chlorophyll, stench', 'stench', 'Pokémon Hierbajo', 'generation-i'),
(45, 45, 'vileplume', '/uploads/pokemon/vileplume.png', '/uploads/pokemon/2d/vileplume.png', '/uploads/pokemon/gif/vileplume.gif', 'Cuanto mayores son sus pétalos, más tóxico es su\npolen. Le pesa la cabeza y le cuesta mantenerla\nerguida.', 44, 12, 186, 'chlorophyll, effect-spore', 'effect-spore', 'Pokémon Flor', 'generation-i'),
(46, 46, 'paras', '/uploads/pokemon/paras.png', '/uploads/pokemon/2d/paras.png', '/uploads/pokemon/gif/paras.gif', 'Lleva en el lomo dos setas parásitas llamadas\ntochukaso, que crecen con él.', NULL, 3, 54, 'effect-spore, dry-skin, damp', 'damp', 'Pokémon Hongo', 'generation-i'),
(47, 47, 'parasect', '/uploads/pokemon/parasect.png', '/uploads/pokemon/2d/parasect.png', '/uploads/pokemon/gif/parasect.gif', 'Parasect está dominado por una seta parásita mayor\nque él. Dispersa esporas venenosas.', 46, 10, 295, 'effect-spore, dry-skin, damp', 'damp', 'Pokémon Hongo', 'generation-i'),
(48, 48, 'venonat', '/uploads/pokemon/venonat.png', '/uploads/pokemon/2d/venonat.png', '/uploads/pokemon/gif/venonat.gif', 'Sus grandes ojos son en realidad grupos de ojos\ndiminutos. Por la noche se siente atraído por la luz.', NULL, 10, 300, 'compound-eyes, tinted-lens, run-away', 'run-away', 'Pokémon Insecto', 'generation-i'),
(49, 49, 'venomoth', '/uploads/pokemon/venomoth.png', '/uploads/pokemon/2d/venomoth.png', '/uploads/pokemon/gif/venomoth.gif', 'Lanza unas escamas que paralizan a cualquiera.\nQuien las toque, no podrá ni ponerse de pie.', 48, 15, 125, 'shield-dust, tinted-lens, wonder-skin', 'wonder-skin', 'Pokémon Polilla Ven.', 'generation-i'),
(50, 50, 'diglett', '/uploads/pokemon/diglett.png', '/uploads/pokemon/2d/diglett.png', '/uploads/pokemon/gif/diglett.gif', 'Vive un metro por debajo del suelo, donde se alimenta\nde raíces. También aparece en la superficie.', NULL, 2, 8, 'sand-veil, arena-trap, sand-force', 'sand-force', 'Pokémon Topo', 'generation-i'),
(51, 51, 'dugtrio', '/uploads/pokemon/dugtrio.png', '/uploads/pokemon/2d/dugtrio.png', '/uploads/pokemon/gif/dugtrio.gif', 'En combate, cava la tierra, se esconde y sale de\nrepente para golpear a su rival. Nunca se sabe por\ndónde puede aparecer.', 50, 7, 333, 'sand-veil, arena-trap, sand-force', 'sand-force', 'Pokémon Topo', 'generation-i'),
(52, 52, 'meowth', '/uploads/pokemon/meowth.png', '/uploads/pokemon/2d/meowth.png', '/uploads/pokemon/gif/meowth.gif', 'Es de naturaleza nocturna. Le atraen los objetos\nbrillantes.', NULL, 4, 42, 'pickup, technician, unnerve', 'unnerve', 'Pokémon Gato Araña', 'generation-i'),
(53, 53, 'persian', '/uploads/pokemon/persian.png', '/uploads/pokemon/2d/persian.png', '/uploads/pokemon/gif/persian.gif', 'Aunque es muy admirado por el pelo, es difícil de\nentrenar como mascota, porque es un poco travieso.', 52, 10, 320, 'limber, technician, unnerve', 'unnerve', 'Pokémon Gato Fino', 'generation-i'),
(54, 54, 'psyduck', '/uploads/pokemon/psyduck.png', '/uploads/pokemon/2d/psyduck.png', '/uploads/pokemon/gif/psyduck.gif', 'Padece continuamente dolores de cabeza. Cuando\nson muy fuertes, empieza a usar misteriosos poderes.', NULL, 8, 196, 'damp, cloud-nine, swift-swim', 'swift-swim', 'Pokémon Pato', 'generation-i'),
(55, 55, 'golduck', '/uploads/pokemon/golduck.png', '/uploads/pokemon/2d/golduck.png', '/uploads/pokemon/gif/golduck.gif', 'Aparece en ríos al anochecer. Puede usar poderes\ntelequinéticos si su frente brilla misteriosamente.', 54, 17, 766, 'damp, cloud-nine, swift-swim', 'swift-swim', 'Pokémon Pato', 'generation-i'),
(56, 56, 'mankey', '/uploads/pokemon/mankey.png', '/uploads/pokemon/2d/mankey.png', '/uploads/pokemon/gif/mankey.gif', 'Es peligroso acercarse si se enfada sin razón aparente,\nya que no distingue entre amigos y enemigos.', NULL, 5, 280, 'vital-spirit, anger-point, defiant', 'defiant', 'Pokémon Mono Cerdo', 'generation-i'),
(57, 57, 'primeape', '/uploads/pokemon/primeape.png', '/uploads/pokemon/2d/primeape.png', '/uploads/pokemon/gif/primeape.gif', 'Solo se calma cuando nadie está cerca. Llegar a ver\nese momento es realmente difícil.', 56, 10, 320, 'vital-spirit, anger-point, defiant', 'defiant', 'Pokémon Mono Cerdo', 'generation-i'),
(58, 58, 'growlithe', '/uploads/pokemon/growlithe.png', '/uploads/pokemon/2d/growlithe.png', '/uploads/pokemon/gif/growlithe.gif', 'Es muy agradable y leal. Para ahuyentar al enemigo,\nse pone a ladrar y a dar bocados.', NULL, 7, 190, 'intimidate, flash-fire, justified', 'justified', 'Pokémon Perrito', 'generation-i'),
(59, 59, 'arcanine', '/uploads/pokemon/arcanine.png', '/uploads/pokemon/2d/arcanine.png', '/uploads/pokemon/gif/arcanine.gif', 'Un Pokémon muy admirado desde la antigüedad por\nsu belleza. Corre ágilmente como si tuviera alas.', 58, 19, 1550, 'intimidate, flash-fire, justified', 'justified', 'Pokémon Leyenda', 'generation-i'),
(60, 60, 'poliwag', '/uploads/pokemon/poliwag.png', '/uploads/pokemon/2d/poliwag.png', '/uploads/pokemon/gif/poliwag.gif', 'Tiene una piel extraordinaria, fina y húmeda, que deja\nentrever las vísceras que tiene dispuestas en espiral.', NULL, 6, 124, 'water-absorb, damp, swift-swim', 'swift-swim', 'Pokémon Renacuajo', 'generation-i'),
(61, 61, 'poliwhirl', '/uploads/pokemon/poliwhirl.png', '/uploads/pokemon/2d/poliwhirl.png', '/uploads/pokemon/gif/poliwhirl.gif', 'Capaz de vivir dentro o fuera del agua. Fuera del agua\nsuda para mantener baboso su cuerpo.', 60, 10, 200, 'water-absorb, damp, swift-swim', 'swift-swim', 'Pokémon Renacuajo', 'generation-i'),
(62, 62, 'poliwrath', '/uploads/pokemon/poliwrath.png', '/uploads/pokemon/2d/poliwrath.png', '/uploads/pokemon/gif/poliwrath.gif', 'Tiene músculos muy desarrollados. Es capaz de nadar\nen el océano sin descanso.', 61, 13, 540, 'water-absorb, damp, swift-swim', 'swift-swim', 'Pokémon Renacuajo', 'generation-i'),
(63, 63, 'abra', '/uploads/pokemon/abra.png', '/uploads/pokemon/2d/abra.png', '/uploads/pokemon/gif/abra.gif', 'Duerme 18 horas al día y mientras lo hace es capaz de\nusar una serie de poderes extrasensoriales.', NULL, 9, 195, 'synchronize, inner-focus, magic-guard', 'magic-guard', 'Pokémon Psi', 'generation-i'),
(64, 64, 'kadabra', '/uploads/pokemon/kadabra.png', '/uploads/pokemon/2d/kadabra.png', '/uploads/pokemon/gif/kadabra.gif', 'Cuando utiliza su poder psíquico, emite poderosas\nondas alfa que pueden destruir dispositivos.', 63, 13, 565, 'synchronize, inner-focus, magic-guard', 'magic-guard', 'Pokémon Psi', 'generation-i'),
(65, 65, 'alakazam', '/uploads/pokemon/alakazam.png', '/uploads/pokemon/2d/alakazam.png', '/uploads/pokemon/gif/alakazam.gif', 'Sus neuronas se multiplican continuamente durante su\nvida. Por eso, siempre lo recuerda todo.', 64, 15, 480, 'synchronize, inner-focus, magic-guard', 'magic-guard', 'Pokémon Psi', 'generation-i'),
(66, 66, 'machop', '/uploads/pokemon/machop.png', '/uploads/pokemon/2d/machop.png', '/uploads/pokemon/gif/machop.gif', 'Levanta un Graveler para mantener sus músculos en\nforma. Domina todas las artes marciales.', NULL, 8, 195, 'guts, no-guard, steadfast', 'steadfast', 'Pokémon Superpoder', 'generation-i'),
(67, 67, 'machoke', '/uploads/pokemon/machoke.png', '/uploads/pokemon/2d/machoke.png', '/uploads/pokemon/gif/machoke.gif', 'Su musculoso cuerpo es tan fuerte que usa un cinto\nantifuerza para controlar sus movimientos.', 66, 15, 705, 'guts, no-guard, steadfast', 'steadfast', 'Pokémon Superpoder', 'generation-i'),
(68, 68, 'machamp', '/uploads/pokemon/machamp.png', '/uploads/pokemon/2d/machamp.png', '/uploads/pokemon/gif/machamp.gif', 'Tiene cuatro brazos tan bien desarrollados que puede\ndar una serie de 1000 puñetazos en cuestión de dos\nsegundos.', 67, 16, 1300, 'guts, no-guard, steadfast', 'steadfast', 'Pokémon Superpoder', 'generation-i'),
(69, 69, 'bellsprout', '/uploads/pokemon/bellsprout.png', '/uploads/pokemon/2d/bellsprout.png', '/uploads/pokemon/gif/bellsprout.gif', 'Aunque su cuerpo es extremadamente delgado, es\nmuy rápido a la hora de capturar sus presas.', NULL, 7, 40, 'chlorophyll, gluttony', 'gluttony', 'Pokémon Flor', 'generation-i'),
(70, 70, 'weepinbell', '/uploads/pokemon/weepinbell.png', '/uploads/pokemon/2d/weepinbell.png', '/uploads/pokemon/gif/weepinbell.gif', 'Las hojas que tiene actúan como cuchillas en\ncombate. Otra de sus armas es el corrosivo fluido\nque expulsa.', 69, 10, 64, 'chlorophyll, gluttony', 'gluttony', 'Pokémon Matamoscas', 'generation-i'),
(71, 71, 'victreebel', '/uploads/pokemon/victreebel.png', '/uploads/pokemon/2d/victreebel.png', '/uploads/pokemon/gif/victreebel.gif', 'Dicen que vive en grandes colonias en el interior de\nlas junglas, aunque nadie ha podido verificarlo.', 70, 17, 155, 'chlorophyll, gluttony', 'gluttony', 'Pokémon Matamoscas', 'generation-i'),
(72, 72, 'tentacool', '/uploads/pokemon/tentacool.png', '/uploads/pokemon/2d/tentacool.png', '/uploads/pokemon/gif/tentacool.gif', 'Su cuerpo se compone casi en exclusiva de agua.\nLanza extraños rayos con sus ojos cristalinos.', NULL, 9, 455, 'clear-body, liquid-ooze, rain-dish', 'rain-dish', 'Pokémon Medusa', 'generation-i'),
(73, 73, 'tentacruel', '/uploads/pokemon/tentacruel.png', '/uploads/pokemon/2d/tentacruel.png', '/uploads/pokemon/gif/tentacruel.gif', 'Cuando caza, extiende los cortos tentáculos que tiene\npara atrapar e inmovilizar a su presa.', 72, 16, 550, 'clear-body, liquid-ooze, rain-dish', 'rain-dish', 'Pokémon Medusa', 'generation-i'),
(74, 74, 'geodude', '/uploads/pokemon/geodude.png', '/uploads/pokemon/2d/geodude.png', '/uploads/pokemon/gif/geodude.gif', 'Aparecen en llanos y montañas. Como parecen rocas,\nla gente se tropieza con ellos o los pisa.', NULL, 4, 200, 'rock-head, sturdy, sand-veil', 'sand-veil', 'Pokémon Roca', 'generation-i'),
(75, 75, 'graveler', '/uploads/pokemon/graveler.png', '/uploads/pokemon/2d/graveler.png', '/uploads/pokemon/gif/graveler.gif', 'De naturaleza descuidada y libre, no le importa\ndañarse cuando baja rodando montañas.', 74, 10, 1050, 'rock-head, sturdy, sand-veil', 'sand-veil', 'Pokémon Roca', 'generation-i'),
(76, 76, 'golem', '/uploads/pokemon/golem.png', '/uploads/pokemon/2d/golem.png', '/uploads/pokemon/gif/golem.gif', 'Se lanza montaña abajo y deja un surco desde la cima\nhasta el pie. Es mejor mantenerse alejado.', 75, 14, 3000, 'rock-head, sturdy, sand-veil', 'sand-veil', 'Pokémon Megatón', 'generation-i'),
(77, 77, 'ponyta', '/uploads/pokemon/ponyta.png', '/uploads/pokemon/2d/ponyta.png', '/uploads/pokemon/gif/ponyta.gif', 'Cuando nace, apenas puede tenerse en pie. Pero va\nfortaleciendo las patas en cuanto empieza a galopar.', NULL, 10, 300, 'run-away, flash-fire, flame-body', 'flame-body', 'Pokémon Caballo Fuego', 'generation-i'),
(78, 78, 'rapidash', '/uploads/pokemon/rapidash.png', '/uploads/pokemon/2d/rapidash.png', '/uploads/pokemon/gif/rapidash.gif', 'Galopa a casi 240 km por hora. Su crin ardiente\nparece una flecha cuando corre.', 77, 17, 950, 'run-away, flash-fire, flame-body', 'flame-body', 'Pokémon Caballo Fuego', 'generation-i'),
(79, 79, 'slowpoke', '/uploads/pokemon/slowpoke.png', '/uploads/pokemon/2d/slowpoke.png', '/uploads/pokemon/gif/slowpoke.gif', 'Descansa ocioso junto al agua. Si algo muerde su\ncola, no lo notará en todo el día.', NULL, 12, 360, 'oblivious, own-tempo, regenerator', 'regenerator', 'Pokémon Atontado', 'generation-i'),
(80, 80, 'slowbro', '/uploads/pokemon/slowbro.png', '/uploads/pokemon/2d/slowbro.png', '/uploads/pokemon/gif/slowbro.gif', 'Tiene una cola tan apetecible, que el Shellder que va\nenganchado a ella no se soltará por nada del mundo.', 79, 16, 785, 'oblivious, own-tempo, regenerator', 'regenerator', 'Pokémon Ermitaño', 'generation-i'),
(81, 81, 'magnemite', '/uploads/pokemon/magnemite.png', '/uploads/pokemon/2d/magnemite.png', '/uploads/pokemon/gif/magnemite.gif', 'Las unidades a los lados de su cuerpo generan\nenergía antigravitatoria para mantenerlo en el aire.', NULL, 3, 60, 'magnet-pull, sturdy, analytic', 'analytic', 'Pokémon Imán', 'generation-i'),
(82, 82, 'magneton', '/uploads/pokemon/magneton.png', '/uploads/pokemon/2d/magneton.png', '/uploads/pokemon/gif/magneton.gif', 'Lo constituye un grupo de Magnemite. Descarga\npotentes ondas magnéticas de alto voltaje.', 81, 10, 600, 'magnet-pull, sturdy, analytic', 'analytic', 'Pokémon Imán', 'generation-i'),
(83, 83, 'farfetchd', '/uploads/pokemon/farfetchd.png', '/uploads/pokemon/2d/farfetchd.png', '/uploads/pokemon/gif/farfetchd.gif', 'El puerro que lleva es su mejor arma. Suele usarlo\ncomo espada para cortar cosas.', NULL, 8, 150, 'keen-eye, inner-focus, defiant', 'defiant', 'Pokémon Pato Salvaje', 'generation-i'),
(84, 84, 'doduo', '/uploads/pokemon/doduo.png', '/uploads/pokemon/2d/doduo.png', '/uploads/pokemon/gif/doduo.gif', 'Este Pokémon de dos cabezas es el resultado de una\nmutación. Cuando corre, puede alcanzar casi 100 km\npor hora.', NULL, 14, 392, 'run-away, early-bird, tangled-feet', 'tangled-feet', 'Pokémon Ave Gemela', 'generation-i'),
(85, 85, 'dodrio', '/uploads/pokemon/dodrio.png', '/uploads/pokemon/2d/dodrio.png', '/uploads/pokemon/gif/dodrio.gif', 'Más vale no perder de vista ninguna de las tres\ncabezas. De lo contrario, el número de picotazos\nserá enorme.', 84, 18, 852, 'run-away, early-bird, tangled-feet', 'tangled-feet', 'Pokémon Ave Triple', 'generation-i'),
(86, 86, 'seel', '/uploads/pokemon/seel.png', '/uploads/pokemon/2d/seel.png', '/uploads/pokemon/gif/seel.gif', 'Este Pokémon vive en icebergs. Nada en el mar y usa\nel cuerno de su cabeza para romper el hielo.', NULL, 11, 900, 'thick-fat, hydration, ice-body', 'ice-body', 'Pokémon León Marino', 'generation-i'),
(87, 87, 'dewgong', '/uploads/pokemon/dewgong.png', '/uploads/pokemon/2d/dewgong.png', '/uploads/pokemon/gif/dewgong.gif', 'Está recubierto de un luminoso pelaje blanco. Este\nPokémon aumenta su actividad cuando bajan las\ntemperaturas.', 86, 17, 1200, 'thick-fat, hydration, ice-body', 'ice-body', 'Pokémon León Marino', 'generation-i'),
(88, 88, 'grimer', '/uploads/pokemon/grimer.png', '/uploads/pokemon/2d/grimer.png', '/uploads/pokemon/gif/grimer.gif', 'Nace de lodo alterado al filtrarse en el agua los\nrayos X reflejados por la Luna. Se alimenta de\nsustancias desagradables.', NULL, 9, 300, 'stench, sticky-hold, poison-touch', 'poison-touch', 'Pokémon Lodo', 'generation-i'),
(89, 89, 'muk', '/uploads/pokemon/muk.png', '/uploads/pokemon/2d/muk.png', '/uploads/pokemon/gif/muk.gif', 'Les encanta reunirse en zonas apestosas donde se\nacumula el lodo, haciendo su olor más insoportable.', 88, 12, 300, 'stench, sticky-hold, poison-touch', 'poison-touch', 'Pokémon Lodo', 'generation-i'),
(90, 90, 'shellder', '/uploads/pokemon/shellder.png', '/uploads/pokemon/2d/shellder.png', '/uploads/pokemon/gif/shellder.gif', 'La concha lo protege de cualquier tipo de ataque.\nSolo es vulnerable cuando se abre.', NULL, 3, 40, 'shell-armor, skill-link, overcoat', 'overcoat', 'Pokémon Bivalvo', 'generation-i'),
(91, 91, 'cloyster', '/uploads/pokemon/cloyster.png', '/uploads/pokemon/2d/cloyster.png', '/uploads/pokemon/gif/cloyster.gif', 'A los Cloyster que viven en las fuertes corrientes\nmarinas les crecen largas y afiladas púas en la concha.', 90, 15, 1325, 'shell-armor, skill-link, overcoat', 'overcoat', 'Pokémon Bivalvo', 'generation-i'),
(92, 92, 'gastly', '/uploads/pokemon/gastly.png', '/uploads/pokemon/2d/gastly.png', '/uploads/pokemon/gif/gastly.gif', 'Su etéreo cuerpo está hecho de gas. Puede envolver\na un oponente de cualquier tamaño hasta ahogarlo.', NULL, 13, 1, 'levitate', NULL, 'Pokémon Gas', 'generation-i'),
(93, 93, 'haunter', '/uploads/pokemon/haunter.png', '/uploads/pokemon/2d/haunter.png', '/uploads/pokemon/gif/haunter.gif', 'Cuando tienes la sensación de que te están\nobservando, seguro que es porque Haunter está\ncerca.', 92, 16, 1, 'levitate', NULL, 'Pokémon Gas', 'generation-i'),
(94, 94, 'gengar', '/uploads/pokemon/gengar.png', '/uploads/pokemon/2d/gengar.png', '/uploads/pokemon/gif/gengar.gif', 'Se esconde entre las sombras. Se dice que donde\nGengar acecha, la temperatura baja 5 °C.', 93, 15, 405, 'cursed-body', NULL, 'Pokémon Sombra', 'generation-i'),
(95, 95, 'onix', '/uploads/pokemon/onix.png', '/uploads/pokemon/2d/onix.png', '/uploads/pokemon/gif/onix.gif', 'Cava a gran velocidad en busca de comida. Los\ntúneles que deja son usados por los Diglett.', NULL, 88, 2100, 'rock-head, sturdy, weak-armor', 'weak-armor', 'Pokémon Serpiente Roca', 'generation-i'),
(96, 96, 'drowzee', '/uploads/pokemon/drowzee.png', '/uploads/pokemon/2d/drowzee.png', '/uploads/pokemon/gif/drowzee.gif', 'Adormece a sus enemigos y se come sus sueños.\nA veces se pone enfermo si come pesadillas.', NULL, 10, 324, 'insomnia, forewarn, inner-focus', 'inner-focus', 'Pokémon Hipnosis', 'generation-i'),
(97, 97, 'hypno', '/uploads/pokemon/hypno.png', '/uploads/pokemon/2d/hypno.png', '/uploads/pokemon/gif/hypno.gif', 'Lleva un péndulo en la mano. Una vez, hizo\ndesaparecer a un niño al que había hipnotizado.', 96, 16, 756, 'insomnia, forewarn, inner-focus', 'inner-focus', 'Pokémon Hipnosis', 'generation-i'),
(98, 98, 'krabby', '/uploads/pokemon/krabby.png', '/uploads/pokemon/2d/krabby.png', '/uploads/pokemon/gif/krabby.gif', 'Ante el peligro, se camufla con las burbujas que\ndesprende su boca, para parecer más grande.', NULL, 4, 65, 'hyper-cutter, shell-armor, sheer-force', 'sheer-force', 'Pokémon Cangrejo', 'generation-i'),
(99, 99, 'kingler', '/uploads/pokemon/kingler.png', '/uploads/pokemon/2d/kingler.png', '/uploads/pokemon/gif/kingler.gif', 'La pinza tan grande que tiene posee una fuerza de\n10 000 caballos de potencia. Pero, por su gran\ntamaño, cuesta moverla.', 98, 13, 600, 'hyper-cutter, shell-armor, sheer-force', 'sheer-force', 'Pokémon Tenaza', 'generation-i'),
(100, 100, 'voltorb', '/uploads/pokemon/voltorb.png', '/uploads/pokemon/2d/voltorb.png', '/uploads/pokemon/gif/voltorb.gif', 'Fue descubierto cuando se crearon las Poké Balls.\nSe dice que tiene algo que ver con ellas.', NULL, 5, 104, 'soundproof, static, aftermath', 'aftermath', 'Pokémon Bola', 'generation-i'),
(101, 101, 'electrode', '/uploads/pokemon/electrode.png', '/uploads/pokemon/2d/electrode.png', '/uploads/pokemon/gif/electrode.gif', 'Explotan a la mínima. Por eso se les tiene mucho\nmiedo. Estos Pokémon reciben el mote de Bomba Ball.', 100, 12, 666, 'soundproof, static, aftermath', 'aftermath', 'Pokémon Bola', 'generation-i'),
(102, 102, 'exeggcute', '/uploads/pokemon/exeggcute.png', '/uploads/pokemon/2d/exeggcute.png', '/uploads/pokemon/gif/exeggcute.gif', 'Estos seis huevos se comunican por telepatía. Si se\nseparan, se pueden reunir rápidamente.', NULL, 4, 25, 'chlorophyll, harvest', 'harvest', 'Pokémon Huevo', 'generation-i'),
(103, 103, 'exeggutor', '/uploads/pokemon/exeggutor.png', '/uploads/pokemon/2d/exeggutor.png', '/uploads/pokemon/gif/exeggutor.gif', 'Sus tres cabezas piensan de forma independiente.\nSin embargo, son amigas y no suelen discutir nunca.', 102, 20, 1200, 'chlorophyll, harvest', 'harvest', 'Pokémon Coco', 'generation-i'),
(104, 104, 'cubone', '/uploads/pokemon/cubone.png', '/uploads/pokemon/2d/cubone.png', '/uploads/pokemon/gif/cubone.gif', 'Lleva puesto el cráneo de su madre. Cuando se siente\nsolo se pone a gritar muy fuerte.', NULL, 4, 65, 'rock-head, lightning-rod, battle-armor', 'battle-armor', 'Pokémon Solitario', 'generation-i'),
(105, 105, 'marowak', '/uploads/pokemon/marowak.png', '/uploads/pokemon/2d/marowak.png', '/uploads/pokemon/gif/marowak.gif', 'Es pequeño y siempre ha sido muy débil. Cuando\nempezó a usar huesos, se volvió más violento.', 104, 10, 450, 'rock-head, lightning-rod, battle-armor', 'battle-armor', 'Pokémon Apilahueso', 'generation-i'),
(106, 106, 'hitmonlee', '/uploads/pokemon/hitmonlee.png', '/uploads/pokemon/2d/hitmonlee.png', '/uploads/pokemon/gif/hitmonlee.gif', 'Encoge y estira las patas a su antojo. Cuando las\nestira, es capaz de propinar una buena patada al\nenemigo.', NULL, 15, 498, 'limber, reckless, unburden', 'unburden', 'Pokémon Patada', 'generation-i'),
(107, 107, 'hitmonchan', '/uploads/pokemon/hitmonchan.png', '/uploads/pokemon/2d/hitmonchan.png', '/uploads/pokemon/gif/hitmonchan.gif', 'Los potentes golpes de sus brazos pueden pulverizar\nel hormigón. Descansa tras luchar tres minutos.', NULL, 14, 502, 'keen-eye, iron-fist, inner-focus', 'inner-focus', 'Pokémon Puñetazo', 'generation-i'),
(108, 108, 'lickitung', '/uploads/pokemon/lickitung.png', '/uploads/pokemon/2d/lickitung.png', '/uploads/pokemon/gif/lickitung.gif', 'Su larga lengua, recubierta de saliva pegajosa, se\npega a todo, por lo que es muy útil.', NULL, 12, 655, 'own-tempo, oblivious, cloud-nine', 'cloud-nine', 'Pokémon Lametazo', 'generation-i'),
(109, 109, 'koffing', '/uploads/pokemon/koffing.png', '/uploads/pokemon/2d/koffing.png', '/uploads/pokemon/gif/koffing.gif', 'Tiene forma de globo y es muy ligero. Está compuesto\npor gases tóxicos y apesta.', NULL, 6, 10, 'levitate, neutralizing-gas, stench', 'stench', 'Pokémon Gas Venenoso', 'generation-i'),
(110, 110, 'weezing', '/uploads/pokemon/weezing.png', '/uploads/pokemon/2d/weezing.png', '/uploads/pokemon/gif/weezing.gif', 'Si uno de los gemelos Koffing se infla, el otro se\ndesinfla. Mezclan constantemente sus venenosos\ngases.', 109, 12, 95, 'levitate, neutralizing-gas, stench', 'stench', 'Pokémon Gas Venenoso', 'generation-i'),
(111, 111, 'rhyhorn', '/uploads/pokemon/rhyhorn.png', '/uploads/pokemon/2d/rhyhorn.png', '/uploads/pokemon/gif/rhyhorn.gif', 'Es muy fuerte, pero no especialmente listo. Es capaz\nde derribar rascacielos usando Placaje varias veces.', NULL, 10, 1150, 'lightning-rod, rock-head, reckless', 'reckless', 'Pokémon Clavos', 'generation-i'),
(112, 112, 'rhydon', '/uploads/pokemon/rhydon.png', '/uploads/pokemon/2d/rhydon.png', '/uploads/pokemon/gif/rhydon.gif', 'La piel le sirve de escudo protector. Puede vivir en\nlava líquida a 2000 °C de temperatura.', 111, 19, 1200, 'lightning-rod, rock-head, reckless', 'reckless', 'Pokémon Taladro', 'generation-i'),
(113, 113, 'chansey', '/uploads/pokemon/chansey.png', '/uploads/pokemon/2d/chansey.png', '/uploads/pokemon/gif/chansey.gif', 'Se dice que reparte felicidad. Se caracteriza por su\ncompasión y reparte sus huevos entre la gente herida.', NULL, 11, 346, 'natural-cure, serene-grace, healer', 'healer', 'Pokémon Huevo', 'generation-i'),
(114, 114, 'tangela', '/uploads/pokemon/tangela.png', '/uploads/pokemon/2d/tangela.png', '/uploads/pokemon/gif/tangela.gif', 'Se camufla con la multitud de lianas que envuelven su\ncuerpo y que no dejan de crecer a lo largo de toda su\nvida.', NULL, 10, 350, 'chlorophyll, leaf-guard, regenerator', 'regenerator', 'Pokémon Enredadera', 'generation-i'),
(115, 115, 'kangaskhan', '/uploads/pokemon/kangaskhan.png', '/uploads/pokemon/2d/kangaskhan.png', '/uploads/pokemon/gif/kangaskhan.gif', 'Lleva a su cría en la bolsa de su panza. Solo deja que\nsu cría salga a jugar cuando no siente peligro.', NULL, 22, 800, 'early-bird, scrappy, inner-focus', 'inner-focus', 'Pokémon Maternal', 'generation-i'),
(116, 116, 'horsea', '/uploads/pokemon/horsea.png', '/uploads/pokemon/2d/horsea.png', '/uploads/pokemon/gif/horsea.gif', 'Es famoso por derribar a bichos voladores lanzando\ntinta desde la superficie del agua.', NULL, 4, 80, 'swift-swim, sniper, damp', 'damp', 'Pokémon Dragón', 'generation-i'),
(117, 117, 'seadra', '/uploads/pokemon/seadra.png', '/uploads/pokemon/2d/seadra.png', '/uploads/pokemon/gif/seadra.gif', 'Las afiladas púas que le recubren el cuerpo se le\nerizan y pueden causar el debilitamiento con solo\ntocarlo.', 116, 12, 250, 'poison-point, sniper, damp', 'damp', 'Pokémon Dragón', 'generation-i'),
(118, 118, 'goldeen', '/uploads/pokemon/goldeen.png', '/uploads/pokemon/2d/goldeen.png', '/uploads/pokemon/gif/goldeen.gif', 'Nada a una velocidad de cinco nudos. Si siente\npeligro, golpea con su afilado cuerno.', NULL, 6, 150, 'swift-swim, water-veil, lightning-rod', 'lightning-rod', 'Pokémon Pez Color', 'generation-i'),
(119, 119, 'seaking', '/uploads/pokemon/seaking.png', '/uploads/pokemon/2d/seaking.png', '/uploads/pokemon/gif/seaking.gif', 'En otoño, cuando se reproducen, se les puede ver\nnadando con energía por ríos y arroyos.', 118, 13, 390, 'swift-swim, water-veil, lightning-rod', 'lightning-rod', 'Pokémon Pez Color', 'generation-i'),
(120, 120, 'staryu', '/uploads/pokemon/staryu.png', '/uploads/pokemon/2d/staryu.png', '/uploads/pokemon/gif/staryu.gif', 'Aunque sus brazos se rompan podrán regenerarse,\nsiempre y cuando su núcleo siga intacto.', NULL, 8, 345, 'illuminate, natural-cure, analytic', 'analytic', 'Pokémon Estrella', 'generation-i'),
(121, 121, 'starmie', '/uploads/pokemon/starmie.png', '/uploads/pokemon/2d/starmie.png', '/uploads/pokemon/gif/starmie.gif', 'Su núcleo central brilla con los colores del arcoíris.\nPara algunos tiene el valor de una gema.', 120, 11, 800, 'illuminate, natural-cure, analytic', 'analytic', 'Pokémon Misterioso', 'generation-i'),
(122, 122, 'mr-mime', '/uploads/pokemon/mr-mime.png', '/uploads/pokemon/2d/mr-mime.png', '/uploads/pokemon/gif/mr-mime.gif', 'Para repeler ataques, solidifica el aire y crea muros\ninvisibles con emanaciones de sus dedos.', NULL, 13, 545, 'soundproof, filter, technician', 'technician', 'Pokémon Barrera', 'generation-i'),
(123, 123, 'scyther', '/uploads/pokemon/scyther.png', '/uploads/pokemon/2d/scyther.png', '/uploads/pokemon/gif/scyther.gif', 'Destroza a su presa con las guadañas que tiene.\nNo es común que use las alas para volar.', NULL, 15, 560, 'swarm, technician, steadfast', 'steadfast', 'Pokémon Mantis', 'generation-i'),
(124, 124, 'jynx', '/uploads/pokemon/jynx.png', '/uploads/pokemon/2d/jynx.png', '/uploads/pokemon/gif/jynx.gif', 'Camina moviendo las caderas de forma llamativa.\nPuede hacer que la gente baile a su ritmo.', NULL, 14, 406, 'oblivious, forewarn, dry-skin', 'dry-skin', 'Pokémon Forma Humana', 'generation-i'),
(125, 125, 'electabuzz', '/uploads/pokemon/electabuzz.png', '/uploads/pokemon/2d/electabuzz.png', '/uploads/pokemon/gif/electabuzz.gif', 'Por la superficie de su piel corre la electricidad. En la\noscuridad, su cuerpo se torna blanquecino.', NULL, 11, 300, 'static, vital-spirit', 'vital-spirit', 'Pokémon Eléctrico', 'generation-i'),
(126, 126, 'magmar', '/uploads/pokemon/magmar.png', '/uploads/pokemon/2d/magmar.png', '/uploads/pokemon/gif/magmar.gif', 'A este Pokémon se lo encontraron cerca de un volcán.\nEsta criatura ígnea tiene una temperatura corporal de\nunos 1200 °C.', NULL, 13, 445, 'flame-body, vital-spirit', 'vital-spirit', 'Pokémon Escupefuego', 'generation-i'),
(127, 127, 'pinsir', '/uploads/pokemon/pinsir.png', '/uploads/pokemon/2d/pinsir.png', '/uploads/pokemon/gif/pinsir.gif', 'Atrapa presas con sus pinzas hasta que las parte en\ndos. Lanza lejos lo que no puede quebrar.', NULL, 15, 550, 'hyper-cutter, mold-breaker, moxie', 'moxie', 'Pokémon Escarabajo', 'generation-i'),
(128, 128, 'tauros', '/uploads/pokemon/tauros.png', '/uploads/pokemon/2d/tauros.png', '/uploads/pokemon/gif/tauros.gif', 'Después de animarse a luchar fustigándose con sus\ntres colas, carga a toda velocidad.', NULL, 14, 884, 'intimidate, anger-point, sheer-force', 'sheer-force', 'Pokémon Toro Bravo', 'generation-i'),
(129, 129, 'magikarp', '/uploads/pokemon/magikarp.png', '/uploads/pokemon/2d/magikarp.png', '/uploads/pokemon/gif/magikarp.gif', 'No es precisamente rápido ni fuerte. Es el Pokémon\nmás debilucho y simplón de todos los que hay.', NULL, 9, 100, 'swift-swim, rattled', 'rattled', 'Pokémon Pez', 'generation-i'),
(130, 130, 'gyarados', '/uploads/pokemon/gyarados.png', '/uploads/pokemon/2d/gyarados.png', '/uploads/pokemon/gif/gyarados.gif', 'En la literatura antigua se dice que un Gyarados\nrebosante de violencia arrasó un poblado.', 129, 65, 2350, 'intimidate, moxie', 'moxie', 'Pokémon Atrocidad', 'generation-i'),
(131, 131, 'lapras', '/uploads/pokemon/lapras.png', '/uploads/pokemon/2d/lapras.png', '/uploads/pokemon/gif/lapras.gif', 'Son buenos de corazón. Muchos fueron capturados\npor ser tan pacíficos. Ahora hay muchos menos.', NULL, 25, 2200, 'water-absorb, shell-armor, hydration', 'hydration', 'Pokémon Transporte', 'generation-i'),
(132, 132, 'ditto', '/uploads/pokemon/ditto.png', '/uploads/pokemon/2d/ditto.png', '/uploads/pokemon/gif/ditto.gif', 'Puede alterar por completo su estructura celular para\nemular cualquier objeto que vea.', NULL, 3, 40, 'limber, imposter', 'imposter', 'Pokémon Transformación', 'generation-i'),
(133, 133, 'eevee', '/uploads/pokemon/eevee.png', '/uploads/pokemon/2d/eevee.png', '/uploads/pokemon/gif/eevee.gif', 'Un extraño Pokémon que se adapta a los entornos\nmás hostiles gracias a sus diferentes evoluciones.', NULL, 3, 65, 'run-away, adaptability, anticipation', 'anticipation', 'Pokémon Evolución', 'generation-i'),
(134, 134, 'vaporeon', '/uploads/pokemon/vaporeon.png', '/uploads/pokemon/2d/vaporeon.png', '/uploads/pokemon/gif/vaporeon.gif', 'Prefiere las bellas costas. Con células parecidas al\nagua, podría fundirse en la misma.', 133, 10, 290, 'water-absorb, hydration', 'hydration', 'Pokémon Burbuja', 'generation-i'),
(135, 135, 'jolteon', '/uploads/pokemon/jolteon.png', '/uploads/pokemon/2d/jolteon.png', '/uploads/pokemon/gif/jolteon.gif', 'Todos los pelos de su cuerpo se ponen de punta si\nempieza a cargarse de electricidad.', 133, 8, 245, 'volt-absorb, quick-feet', 'quick-feet', 'Pokémon Relámpago', 'generation-i'),
(136, 136, 'flareon', '/uploads/pokemon/flareon.png', '/uploads/pokemon/2d/flareon.png', '/uploads/pokemon/gif/flareon.gif', 'Almacena llamas en su cuerpo, que alcanza una\ntemperatura de 900 °C antes de un combate.', 133, 9, 250, 'flash-fire, guts', 'guts', 'Pokémon Llama', 'generation-i'),
(137, 137, 'porygon', '/uploads/pokemon/porygon.png', '/uploads/pokemon/2d/porygon.png', '/uploads/pokemon/gif/porygon.gif', 'Pokémon creado por el hombre tras muchas\ninvestigaciones. Sus habilidades son básicas.', NULL, 8, 365, 'trace, download, analytic', 'analytic', 'Pokémon Virtual', 'generation-i'),
(138, 138, 'omanyte', '/uploads/pokemon/omanyte.png', '/uploads/pokemon/2d/omanyte.png', '/uploads/pokemon/gif/omanyte.gif', 'Pokémon prehistórico que vivió en el océano\nprimordial. Para nadar se valía de sus 10 tentáculos.', NULL, 4, 75, 'swift-swim, shell-armor, weak-armor', 'weak-armor', 'Pokémon Espiral', 'generation-i'),
(139, 139, 'omastar', '/uploads/pokemon/omastar.png', '/uploads/pokemon/2d/omastar.png', '/uploads/pokemon/gif/omastar.gif', 'Tiene los tentáculos tan desarrollados que le sirven de\nmanos y pies. Con ellos atrapa a su presa y le da un\nbocado.', 138, 10, 350, 'swift-swim, shell-armor, weak-armor', 'weak-armor', 'Pokémon Espiral', 'generation-i'),
(140, 140, 'kabuto', '/uploads/pokemon/kabuto.png', '/uploads/pokemon/2d/kabuto.png', '/uploads/pokemon/gif/kabuto.gif', 'Se cree que habitó las playas hace 300 millones de\naños. Se protege con una dura concha.', NULL, 5, 115, 'swift-swim, battle-armor, weak-armor', 'weak-armor', 'Pokémon Armazón', 'generation-i'),
(141, 141, 'kabutops', '/uploads/pokemon/kabutops.png', '/uploads/pokemon/2d/kabutops.png', '/uploads/pokemon/gif/kabutops.gif', 'Repliega sus extremidades en el agua para hacerse\nmás compacto, y mueve su concha para nadar rápido.', 140, 13, 405, 'swift-swim, battle-armor, weak-armor', 'weak-armor', 'Pokémon Armazón', 'generation-i'),
(142, 142, 'aerodactyl', '/uploads/pokemon/aerodactyl.png', '/uploads/pokemon/2d/aerodactyl.png', '/uploads/pokemon/gif/aerodactyl.gif', 'Se regeneró a partir de material genético de un\ndinosaurio encontrado en ámbar. Cuando vuela emite\nescandalosos alaridos.', NULL, 18, 590, 'rock-head, pressure, unnerve', 'unnerve', 'Pokémon Fósil', 'generation-i'),
(143, 143, 'snorlax', '/uploads/pokemon/snorlax.png', '/uploads/pokemon/2d/snorlax.png', '/uploads/pokemon/gif/snorlax.gif', 'No se encuentra satisfecho hasta que no se come\n400 kg de comida cada día. Cuando acaba de comer,\nse queda dormido.', NULL, 21, 4600, 'immunity, thick-fat, gluttony', 'gluttony', 'Pokémon Dormir', 'generation-i'),
(144, 144, 'articuno', '/uploads/pokemon/articuno.png', '/uploads/pokemon/2d/articuno.png', '/uploads/pokemon/gif/articuno.gif', 'Legendario Pokémon pájaro capaz de generar\nventiscas congelando la humedad del aire.', NULL, 17, 554, 'pressure, snow-cloak', 'snow-cloak', 'Pokémon Congelar', 'generation-i'),
(145, 145, 'zapdos', '/uploads/pokemon/zapdos.png', '/uploads/pokemon/2d/zapdos.png', '/uploads/pokemon/gif/zapdos.gif', 'Es un legendario pájaro Pokémon. Dicen que aparece\nentre las nubes lanzando enormes rayos brillantes.', NULL, 16, 526, 'pressure, static', 'static', 'Pokémon Eléctrico', 'generation-i'),
(146, 146, 'moltres', '/uploads/pokemon/moltres.png', '/uploads/pokemon/2d/moltres.png', '/uploads/pokemon/gif/moltres.gif', 'Es más conocido como el legendario pájaro de fuego.\nCon cada aleteo crea brillantes llamas.', NULL, 20, 600, 'pressure, flame-body', 'flame-body', 'Pokémon Llama', 'generation-i'),
(147, 147, 'dratini', '/uploads/pokemon/dratini.png', '/uploads/pokemon/2d/dratini.png', '/uploads/pokemon/gif/dratini.gif', 'Se le llama el Pokémon Espejismo porque son muy\npocos los que lo han visto. Se encontró su muda.', NULL, 18, 33, 'shed-skin, marvel-scale', 'marvel-scale', 'Pokémon Dragón', 'generation-i'),
(148, 148, 'dragonair', '/uploads/pokemon/dragonair.png', '/uploads/pokemon/2d/dragonair.png', '/uploads/pokemon/gif/dragonair.gif', 'Sus cristalinos orbes parecen darle al Pokémon el\npoder de controlar el clima libremente.', 147, 40, 165, 'shed-skin, marvel-scale', 'marvel-scale', 'Pokémon Dragón', 'generation-i'),
(149, 149, 'dragonite', '/uploads/pokemon/dragonite.png', '/uploads/pokemon/2d/dragonite.png', '/uploads/pokemon/gif/dragonite.gif', 'A pesar del tamaño que tiene y de lo pesado que es,\npuede volar. Es capaz de dar la vuelta al mundo en\nsolo 16 horas.', 148, 22, 2100, 'inner-focus, multiscale', 'multiscale', 'Pokémon Dragón', 'generation-i'),
(150, 150, 'mewtwo', '/uploads/pokemon/mewtwo.png', '/uploads/pokemon/2d/mewtwo.png', '/uploads/pokemon/gif/mewtwo.gif', 'Fue creado por un científico tras años de horribles\nexperimentos de ingeniería genética.', NULL, 20, 1220, 'pressure, unnerve', 'unnerve', 'Pokémon Genético', 'generation-i'),
(151, 151, 'mew', '/uploads/pokemon/mew.png', '/uploads/pokemon/2d/mew.png', '/uploads/pokemon/gif/mew.gif', 'Varios científicos lo consideran el antecesor de los\nPokémon porque usa todo tipo de movimientos.', NULL, 4, 40, 'synchronize', NULL, 'Pokémon Nueva Especie', 'generation-i');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Pokemon_Tipo`
--

CREATE TABLE `Pokemon_Tipo` (
  `ID_Pokemon` int NOT NULL,
  `ID_Tipo` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `Pokemon_Tipo`
--

INSERT INTO `Pokemon_Tipo` (`ID_Pokemon`, `ID_Tipo`) VALUES
(1, 1),
(2, 1),
(3, 1),
(43, 1),
(44, 1),
(45, 1),
(46, 1),
(47, 1),
(69, 1),
(70, 1),
(71, 1),
(102, 1),
(103, 1),
(114, 1),
(1, 2),
(2, 2),
(3, 2),
(13, 2),
(14, 2),
(15, 2),
(23, 2),
(24, 2),
(29, 2),
(30, 2),
(31, 2),
(32, 2),
(33, 2),
(34, 2),
(41, 2),
(42, 2),
(43, 2),
(44, 2),
(45, 2),
(48, 2),
(49, 2),
(69, 2),
(70, 2),
(71, 2),
(72, 2),
(73, 2),
(88, 2),
(89, 2),
(92, 2),
(93, 2),
(94, 2),
(109, 2),
(110, 2),
(4, 3),
(5, 3),
(6, 3),
(37, 3),
(38, 3),
(58, 3),
(59, 3),
(77, 3),
(78, 3),
(126, 3),
(136, 3),
(146, 3),
(6, 4),
(12, 4),
(16, 4),
(17, 4),
(18, 4),
(21, 4),
(22, 4),
(41, 4),
(42, 4),
(83, 4),
(84, 4),
(85, 4),
(123, 4),
(130, 4),
(142, 4),
(144, 4),
(145, 4),
(146, 4),
(149, 4),
(7, 5),
(8, 5),
(9, 5),
(54, 5),
(55, 5),
(60, 5),
(61, 5),
(62, 5),
(72, 5),
(73, 5),
(79, 5),
(80, 5),
(86, 5),
(87, 5),
(90, 5),
(91, 5),
(98, 5),
(99, 5),
(116, 5),
(117, 5),
(118, 5),
(119, 5),
(120, 5),
(121, 5),
(129, 5),
(130, 5),
(131, 5),
(134, 5),
(138, 5),
(139, 5),
(140, 5),
(141, 5),
(10, 6),
(11, 6),
(12, 6),
(13, 6),
(14, 6),
(15, 6),
(46, 6),
(47, 6),
(48, 6),
(49, 6),
(123, 6),
(127, 6),
(16, 7),
(17, 7),
(18, 7),
(19, 7),
(20, 7),
(21, 7),
(22, 7),
(39, 7),
(40, 7),
(52, 7),
(53, 7),
(83, 7),
(84, 7),
(85, 7),
(108, 7),
(113, 7),
(115, 7),
(128, 7),
(132, 7),
(133, 7),
(137, 7),
(143, 7),
(25, 8),
(26, 8),
(81, 8),
(82, 8),
(100, 8),
(101, 8),
(125, 8),
(135, 8),
(145, 8),
(27, 9),
(28, 9),
(31, 9),
(34, 9),
(50, 9),
(51, 9),
(74, 9),
(75, 9),
(76, 9),
(95, 9),
(104, 9),
(105, 9),
(111, 9),
(112, 9),
(35, 10),
(36, 10),
(39, 10),
(40, 10),
(122, 10),
(56, 11),
(57, 11),
(62, 11),
(66, 11),
(67, 11),
(68, 11),
(106, 11),
(107, 11),
(63, 12),
(64, 12),
(65, 12),
(79, 12),
(80, 12),
(96, 12),
(97, 12),
(102, 12),
(103, 12),
(121, 12),
(122, 12),
(124, 12),
(150, 12),
(151, 12),
(74, 13),
(75, 13),
(76, 13),
(95, 13),
(111, 13),
(112, 13),
(138, 13),
(139, 13),
(140, 13),
(141, 13),
(142, 13),
(81, 14),
(82, 14),
(87, 15),
(91, 15),
(124, 15),
(131, 15),
(144, 15),
(92, 16),
(93, 16),
(94, 16),
(147, 17),
(148, 17),
(149, 17);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Tipos`
--

CREATE TABLE `Tipos` (
  `ID_Tipos` int NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Icono` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `Tipos`
--

INSERT INTO `Tipos` (`ID_Tipos`, `Nombre`, `Icono`) VALUES
(1, 'grass', '/uploads/tipos/grass.png'),
(2, 'poison', '/uploads/tipos/poison.png'),
(3, 'fire', '/uploads/tipos/fire.png'),
(4, 'flying', '/uploads/tipos/flying.png'),
(5, 'water', '/uploads/tipos/water.png'),
(6, 'bug', '/uploads/tipos/bug.png'),
(7, 'normal', '/uploads/tipos/normal.png'),
(8, 'electric', '/uploads/tipos/electric.png'),
(9, 'ground', '/uploads/tipos/ground.png'),
(10, 'fairy', '/uploads/tipos/fairy.png'),
(11, 'fighting', '/uploads/tipos/fighting.png'),
(12, 'psychic', '/uploads/tipos/psychic.png'),
(13, 'rock', '/uploads/tipos/rock.png'),
(14, 'steel', '/uploads/tipos/steel.png'),
(15, 'ice', '/uploads/tipos/ice.png'),
(16, 'ghost', '/uploads/tipos/ghost.png'),
(17, 'dragon', '/uploads/tipos/dragon.png'),
(18, 'dark', '/uploads/tipos/dark.png');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Tipo_Eficaz`
--

CREATE TABLE `Tipo_Eficaz` (
  `ID_Tipo_Origen` int NOT NULL,
  `ID_Tipo_Destino` int NOT NULL,
  `Multiplicador` decimal(3,2) NOT NULL DEFAULT '1.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `Tipo_Eficaz`
--

INSERT INTO `Tipo_Eficaz` (`ID_Tipo_Origen`, `ID_Tipo_Destino`, `Multiplicador`) VALUES
(1, 1, 0.50),
(1, 2, 0.50),
(1, 3, 0.50),
(1, 4, 0.50),
(1, 5, 2.00),
(1, 6, 0.50),
(1, 9, 2.00),
(1, 13, 2.00),
(1, 14, 0.50),
(1, 17, 0.50),
(2, 1, 2.00),
(2, 2, 0.50),
(2, 9, 0.50),
(2, 10, 2.00),
(2, 13, 0.50),
(2, 14, 0.00),
(2, 16, 0.50),
(3, 1, 2.00),
(3, 3, 0.50),
(3, 5, 0.50),
(3, 6, 2.00),
(3, 13, 0.50),
(3, 14, 2.00),
(3, 15, 2.00),
(3, 17, 0.50),
(4, 1, 2.00),
(4, 6, 2.00),
(4, 8, 0.50),
(4, 11, 2.00),
(4, 13, 0.50),
(4, 14, 0.50),
(5, 1, 0.50),
(5, 3, 2.00),
(5, 5, 0.50),
(5, 9, 2.00),
(5, 13, 2.00),
(5, 17, 0.50),
(6, 1, 2.00),
(6, 2, 0.50),
(6, 3, 0.50),
(6, 4, 0.50),
(6, 10, 0.50),
(6, 11, 0.50),
(6, 12, 2.00),
(6, 14, 0.50),
(6, 16, 0.50),
(6, 18, 2.00),
(7, 11, 0.50),
(7, 13, 0.50),
(7, 14, 0.50),
(7, 16, 0.00),
(8, 1, 0.50),
(8, 4, 2.00),
(8, 5, 2.00),
(8, 8, 0.50),
(8, 9, 0.00),
(8, 17, 0.50),
(9, 1, 0.50),
(9, 2, 2.00),
(9, 3, 2.00),
(9, 4, 0.00),
(9, 6, 0.50),
(9, 8, 2.00),
(9, 13, 2.00),
(9, 14, 2.00),
(10, 2, 0.50),
(10, 3, 0.50),
(10, 11, 2.00),
(10, 14, 0.50),
(10, 17, 2.00),
(10, 18, 2.00),
(11, 2, 0.50),
(11, 4, 0.50),
(11, 6, 0.50),
(11, 7, 2.00),
(11, 10, 0.50),
(11, 12, 0.50),
(11, 13, 2.00),
(11, 14, 2.00),
(11, 15, 2.00),
(11, 16, 0.00),
(11, 18, 2.00),
(12, 2, 2.00),
(12, 11, 2.00),
(12, 12, 0.50),
(12, 14, 0.50),
(12, 18, 0.00),
(13, 3, 2.00),
(13, 4, 2.00),
(13, 6, 2.00),
(13, 9, 0.50),
(13, 11, 0.50),
(13, 14, 0.50),
(13, 15, 2.00),
(14, 3, 0.50),
(14, 5, 0.50),
(14, 8, 0.50),
(14, 10, 2.00),
(14, 13, 2.00),
(14, 14, 0.50),
(14, 15, 2.00),
(15, 1, 2.00),
(15, 3, 0.50),
(15, 4, 2.00),
(15, 5, 0.50),
(15, 9, 2.00),
(15, 14, 0.50),
(15, 15, 0.50),
(15, 17, 2.00),
(16, 7, 0.00),
(16, 12, 2.00),
(16, 16, 2.00),
(16, 18, 0.50),
(17, 10, 0.00),
(17, 14, 0.50),
(17, 17, 2.00),
(18, 10, 0.50),
(18, 11, 0.50),
(18, 12, 2.00),
(18, 16, 2.00),
(18, 18, 0.50);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Usuario`
--

CREATE TABLE `Usuario` (
  `ID_Usuario` int NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Correo` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `Usuario`
--

INSERT INTO `Usuario` (`ID_Usuario`, `Nombre`, `Correo`, `Pass`) VALUES
(1, 'Yesua', 'yesua@example.com', '123456'),
(3, 'Ash', 'ash@poke.com', '$2y$10$ZPrUEqpLKMxKcV9kUg9U1OKK4EtRzG1Og.AOGy/h/CP3opdWJzBzC');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `doctrine_migration_versions`
--
ALTER TABLE `doctrine_migration_versions`
  ADD PRIMARY KEY (`version`);

--
-- Indices de la tabla `Equipo`
--
ALTER TABLE `Equipo`
  ADD PRIMARY KEY (`ID_Equipo`),
  ADD KEY `ID_Usuario` (`ID_Usuario`);

--
-- Indices de la tabla `Equipos_Pokemon`
--
ALTER TABLE `Equipos_Pokemon`
  ADD PRIMARY KEY (`ID_Equipo`,`ID_Pokemon`),
  ADD KEY `ID_Pokemon` (`ID_Pokemon`);

--
-- Indices de la tabla `Pokemon`
--
ALTER TABLE `Pokemon`
  ADD PRIMARY KEY (`ID_Pokemon`);

--
-- Indices de la tabla `Pokemon_Tipo`
--
ALTER TABLE `Pokemon_Tipo`
  ADD PRIMARY KEY (`ID_Pokemon`,`ID_Tipo`),
  ADD KEY `ID_Tipo` (`ID_Tipo`);

--
-- Indices de la tabla `Tipos`
--
ALTER TABLE `Tipos`
  ADD PRIMARY KEY (`ID_Tipos`),
  ADD UNIQUE KEY `Nombre` (`Nombre`);

--
-- Indices de la tabla `Tipo_Eficaz`
--
ALTER TABLE `Tipo_Eficaz`
  ADD PRIMARY KEY (`ID_Tipo_Origen`,`ID_Tipo_Destino`),
  ADD KEY `ID_Tipo_Destino` (`ID_Tipo_Destino`);

--
-- Indices de la tabla `Usuario`
--
ALTER TABLE `Usuario`
  ADD PRIMARY KEY (`ID_Usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `Equipo`
--
ALTER TABLE `Equipo`
  MODIFY `ID_Equipo` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `Pokemon`
--
ALTER TABLE `Pokemon`
  MODIFY `ID_Pokemon` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;

--
-- AUTO_INCREMENT de la tabla `Tipos`
--
ALTER TABLE `Tipos`
  MODIFY `ID_Tipos` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `Usuario`
--
ALTER TABLE `Usuario`
  MODIFY `ID_Usuario` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `Equipo`
--
ALTER TABLE `Equipo`
  ADD CONSTRAINT `Equipo_ibfk_1` FOREIGN KEY (`ID_Usuario`) REFERENCES `Usuario` (`ID_Usuario`) ON DELETE CASCADE;

--
-- Filtros para la tabla `Equipos_Pokemon`
--
ALTER TABLE `Equipos_Pokemon`
  ADD CONSTRAINT `Equipos_Pokemon_ibfk_1` FOREIGN KEY (`ID_Equipo`) REFERENCES `Equipo` (`ID_Equipo`) ON DELETE CASCADE,
  ADD CONSTRAINT `Equipos_Pokemon_ibfk_2` FOREIGN KEY (`ID_Pokemon`) REFERENCES `Pokemon` (`ID_Pokemon`) ON DELETE CASCADE;

--
-- Filtros para la tabla `Pokemon_Tipo`
--
ALTER TABLE `Pokemon_Tipo`
  ADD CONSTRAINT `Pokemon_Tipo_ibfk_1` FOREIGN KEY (`ID_Pokemon`) REFERENCES `Pokemon` (`ID_Pokemon`) ON DELETE CASCADE,
  ADD CONSTRAINT `Pokemon_Tipo_ibfk_2` FOREIGN KEY (`ID_Tipo`) REFERENCES `Tipos` (`ID_Tipos`) ON DELETE CASCADE;

--
-- Filtros para la tabla `Tipo_Eficaz`
--
ALTER TABLE `Tipo_Eficaz`
  ADD CONSTRAINT `Tipo_Eficaz_ibfk_1` FOREIGN KEY (`ID_Tipo_Origen`) REFERENCES `Tipos` (`ID_Tipos`) ON DELETE CASCADE,
  ADD CONSTRAINT `Tipo_Eficaz_ibfk_2` FOREIGN KEY (`ID_Tipo_Destino`) REFERENCES `Tipos` (`ID_Tipos`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
